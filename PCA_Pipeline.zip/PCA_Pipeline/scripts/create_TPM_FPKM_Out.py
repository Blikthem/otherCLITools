#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 11:15:20 2019

@author: claypooldj
"""
import os
import pandas as pd
import sys

inputDir=sys.argv[1]
#"/Volumes/Untitled/Output/rRNA/SummaryChecker"


#Two master data frames to store values in
TPM_Master=pd.DataFrame()
FPKM_Master=pd.DataFrame()

#Loop over each RSEM directory in the input directory
for indivDir in os.listdir(inputDir):
    #If that is a pipelien output directory for RSEM...
    if "RSEM_" in indivDir:
        print("IndivDir",indivDir)
        #Then read in the corresponding expression matrix
        newDF = pd.read_csv(inputDir+"/"+indivDir+"/rsem_.genes.results", sep='\t')
        newDF = newDF.drop("transcript_id(s)", axis=1)
        newDF = newDF.drop("length", axis=1)
        newDF = newDF.drop("effective_length", axis=1)
        newDF = newDF.drop("expected_count", axis=1)
        
        #Create the TPM matrix
        indivTPM=newDF.drop("FPKM", axis=1)
        
        #Create the FPKM matrix
        indivFPKM=newDF.drop("TPM",axis=1)
        
        #Change the name to match that of the sample
        sampleName=indivDir.replace("RSEM_", "")
        
        indivTPM=indivTPM.rename(columns = {'TPM':sampleName})
        indivFPKM=indivFPKM.rename(columns = {'FPKM':sampleName})

        #Merge to the master
            #If empty, set as master
        if len(TPM_Master.columns)==0:
            TPM_Master=indivTPM
            FPKM_Master=indivFPKM
        else:
            TPM_Master=TPM_Master.merge(indivTPM, on='gene_id', how='left')
            FPKM_Master=FPKM_Master.merge(indivFPKM, on='gene_id', how='left')
        
print(TPM_Master)
print(FPKM_Master)

#Output the results into the parent directory into two seperate gene expression csv files.
TPM_Master.to_csv(inputDir+"/geneExpressionMatrix_TPM.csv",index=False)
FPKM_Master.to_csv(inputDir+"/geneExpressionMatrix_FPKM.csv",index=False)