module load star/2.7.0a
STAR --genomeDir /home/claypooldj/genomes/star-genome --readFilesIn mapped_t3.fastq
