toS=$(pwd)
mine=$(find $toS -name "PCA_Pipe.sh" -print)
echo $mine

DIR=`dirname $mine`
echo $DIR
