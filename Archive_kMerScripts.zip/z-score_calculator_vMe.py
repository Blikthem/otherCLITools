### VERSION 2 - z-score_calculator for difference in population proportions (orig for kmers)
#
## Uses the formula at: http://www.socscistatistics.com/tests/ztest/ 
## Uses the pooled sample proportion formula at: http://stattrek.com/hypothesis-test/difference-in-proportions.aspx
#
## Added/clarified some variables for score calculation
# N_obs : observed or experimental population size
# N_exp : expected or background population size
# p_obs : proportion of observed hits for the given kmer over N_obs
# p_exp : proportion of	observed hits for the given kmer over N_exp
# pooled_proportion : pooled sample proportion used to calculate standard_error
# standard_error : denominator for the z-score formula
#
#######################################################

## Import modules
import re
import math
import argparse
import sys


## Set up argument parser
parser = argparse.ArgumentParser(description='read in observed kmer counts, expected kmer counts, and output z-score and frequency file')
parser.add_argument('kmer_obs', type=argparse.FileType('r'), help="name of observed kmer-counts file")
parser.add_argument('kmer_exp', type=argparse.FileType('r'), help="name of expected kmer-counts file")
parser.add_argument('out', type=argparse.FileType('w'), help="name of output z-score and freq file")
args = parser.parse_args()


## Initiate dictionaries and variables
kmer_obs_counts = {}
kmer_exp_counts = {}
proportion_exp = {}
N_obs = 0
N_exp = 0

## Mean and Standard Deviation variables
sum_proportion_exp = 0
mean_proportion_exp = 0
sum_squared_differences_exp = 0
mean_squared_differences_exp = 0
stdev_proportion_exp = 0



## Iterate through observed input file, extract row names and counts/scores
for line in args.kmer_obs:
	line_array = line.strip().split()
	kmer = line_array[0]
	kmer_count = int(line_array[1])
	kmer_obs_counts[kmer] = kmer_count
	N_obs += kmer_count

## Iterate through expected input file, extract row names and counts/scores
for line in args.kmer_exp:
	line_array = line.strip().split()
	kmer = line_array[0]
	kmer_count = int(line_array[1])
	kmer_exp_counts[kmer] = kmer_count
	N_exp += kmer_count
		

## Convert population sizes from int to float for proper division
N_obs = float(N_obs)
N_exp = float(N_exp)



## Calculate expected mean and standard deviation

for key in kmer_exp_counts:
    p_exp = kmer_exp_counts[key] / N_exp	
    proportion_exp[key] = p_exp
    sum_proportion_exp += p_exp
    
sum_proportion_exp = float(sum_proportion_exp)
mean_proportion_exp = sum_proportion_exp / len(kmer_exp_counts)

for key in kmer_exp_counts:
	difference = proportion_exp[key] - mean_proportion_exp
	squared_difference = math.pow(difference, 2)
	sum_squared_differences_exp += squared_difference

mean_squared_differences_exp = sum_squared_differences_exp / len(kmer_exp_counts)
stdev_proportion_exp = math.sqrt(mean_squared_differences_exp)

#print "Mean Proportion in Expected/Control Population: ",mean_proportion_exp
#print "Standard Deviation of Proportion in Expected/Control Population: ",stdev_proportion_exp 


## Calculate z-scores and frequencies for each kmer, output to file
for key in kmer_obs_counts:
	
	#Add logic for if one key is only in one of the files
	if key not in proportion_exp:
		print("Kmer in only obs counts: ")
		print(key)
		continue

    #SHUNT APPLIED here
	if N_obs==0 or kmer_obs_counts[key]<=0:
		print(key,"has no observed occurances")
		args.out.write('%s\t%r\t%r\n' %  (key,0,0))
		continue
    
    
        
	p_obs = kmer_obs_counts[key] / N_obs
	p_exp = proportion_exp[key]
	

	z_score = (p_obs - p_exp) / stdev_proportion_exp
	
	obs_frequency = math.log10(kmer_obs_counts[key])

	args.out.write('%s\t%r\t%r\n' %  (key,z_score,obs_frequency))

