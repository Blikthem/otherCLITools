#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 15 10:34:38 2020

@author: claypooldj
"""
import os
import pandas as pd
from functools import reduce

rootdir = '/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged'

theDFs=[]
for subdir, dirs, files in os.walk(rootdir):
    if "_Compiled" in subdir:
        toAdd=subdir+"/countSummary.csv"
        theDF=pd.read_csv(toAdd)
        theDF.columns=["Header",subdir]
        theDFs.append(theDF)
        print(theDF)

df_final=reduce(lambda x, y: pd.merge(x, y, on = 'Header'), theDFs)

df_final.to_csv(rootdir+"/consolidate_joined.csv")