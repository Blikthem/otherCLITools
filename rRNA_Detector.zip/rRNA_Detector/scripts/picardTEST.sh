java -jar /cm/shared/apps/picard/2.18.25/build/libs/picard.jar CollectRnaSeqMetrics I= O=picardTEST.txt REF_FLAT=/home/claypooldj/genomes/refFlat.txt STRAND=NONE
