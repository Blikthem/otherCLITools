module load star/2.7.0a
module load python/3.7.2

#Inputs----------------------------------------------------------------------------
inputDir=$1
genomeDirectory=$2
refFlat=$3
picJar=$4
#----------------------------------------------------------------------------------

echo "Running "

toRun=""
cd $inputDir

for d in  *Compiled; do
 toRun+=$d
 toRun+=" "
done

for d in $toRun; do
 echo "Processing:" $d
 /home/claypooldj/rRNADepletion/blat/pairedStar_CLI.sh $genomeDirectory $refFlat $picJar $outDir
done
