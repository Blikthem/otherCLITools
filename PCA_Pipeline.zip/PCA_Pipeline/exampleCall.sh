#Note: Dependencies loaded in the Pipeline call so you may have to update them manually if they get out of date.

#Run the program (PCA_Pipe.sh) from where it is housed.
/home/claypooldj/PCA_Pipeline/scripts/PCA_Pipe.sh /home/claypooldj/PCA_Pipeline/testFQs /home/claypooldj/genomes/star-genome /home/claypooldj/PCA_Pipeline/outDir/ /home/claypooldj/genomes/RSEM/rsem_hg38 [["sub1","sub3"],["sub2","sub4"],["T1","T2"]]
