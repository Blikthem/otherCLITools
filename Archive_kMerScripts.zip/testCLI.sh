echo $0
echo "${0%/*}"
echo $1
echo $2

scriptDir=$(pwd)
echo $scriptDir

