#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 27 12:35:35 2019

@author: claypooldj
"""
import sys

#Name to output
fOut=open(sys.argv[2], "w")
f = open(sys.argv[1], "r")
    #Read in each line
for line in f:
    if "--" in line and len(line)==3:
        print("-- found in:")

    else:
        fOut.write(line)
                
