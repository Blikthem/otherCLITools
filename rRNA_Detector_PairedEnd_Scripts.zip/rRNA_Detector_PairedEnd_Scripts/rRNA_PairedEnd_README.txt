Workflow
Unfortunately the work flow for detecting rRNA in paired end reads is a bit painful since I never had time to automate it fully. That means you have to follow these different steps, implementing scripts along the way:
1. Extract all the FASTQs and put them in the same directory (both R1’s and R2’s).
2. Run blat_engine_dir.sh on this input directory. This was the automated pipeline designed for non-paired end reads and will count occurrences in the individual fastq files.
3. For each pair of directories in the output directory, run rRNA_Consolidate_Paired_CLI.py (submit a r-Compile.sh script for each of them). This will create compiled directories containing the sequences that are both aligned to rRNA, one was aligned to rRNA, or neither were.
4. Run rRNA_Consolidate_GetOutput.py (all you have to change is the rootDir variable to the directory containing all the compiled directories) in order to get a nice spreadsheet summarizing the both/neither/one counts for all files you studied. 
5. For each compiled directory, run a STAR_forPCA.sh in order to run a transcriptome level star on the compiled files. These files, found in the _PCA subdirectories, can be used for differential expression or any other more traditional downstream analysis steps. You might want to recursively copy them with better naming so there is no over-writing. You could use the script  PCA_Pipe_AfterAligned_Paired2.sh if you want, which takes a directory of sam files and runs differential expression, quantification, and PCA on them.
6. Optional - If you want a straight (non-transcript level) star alignment or to use picard tools to collect metrics you can use run_STAR_Picard.sh. If you want help visualizing the results you can use collectPicard.py and/or picardPie.py.

Good luck!

Another way to look at it:
Step 2
Scripts: blat_engine_dir.sh (the boat rRNA detection pipeline)
Output: Detects rRNA in individual paired fastq’s

Step 3
Scripts: rRNA_Consolidate_Paired_CLI.py, r_Compile.sh
Output: Creates consolidates directories which look at each read in each paired fastq and decides if its aligned to rRNA once, twice, or never.

Step 4
Scripts: rRNA_Consolidate_GetOutput.py
Output: CSV file summarizing aligned in paired end fastq files (one, both, or neither).

Step 5
Scripts: STAR_forPCA.sh
Output: _PCA subdirectories with alignment files for all groups for each paired end combo.

Step 6:
Scripts: run_STAR_Picard.sh, collectPicard.py, picardPie.py
Output: Picard analysis and star alignment.


For an example of how I used it you can look in the directory 2020/blat_pipeline_output_unmerged (which is where I generated the files) and then go 2020/diffExp to see how I visualized the results. Note: those weren’t full paths. Right now its in /home/claypooldj/rRNADepletion/ but that could change.
