#!/bin/sh
module load star/2.7.0a
module load python/3.7.2

#README - Inputs ---------------------------------------------------
#Directory containing all of the fastqs to search for rRNA, with path (input 1)
#Directory with all of the rRNA reference FASTAS (input 2)
#Blat executable (input 3)
#Output directory (input 4)
#Directory containing the blat_engine_indivFQ.sh executable (input 5)
#Directory containg the star index files (input 6)
#Ref flat file (input 7)
#Path to the picard jar file (input 8)
#----------------------------------------------------------------------------------------
#Get the name of the individual exeutable
indivEx=$5
indivEx+="/blat_engine_indivFQ.sh"
echo "$indivEx"

#For each fastq in the input directory
cd $1
for f in *fastq
do
 #Fastq name (without extension or file path)
 fqname=$(basename "$f" .fastq)

 #Create the output directory
 outDir=$4
 outDir+="/"
 outDir+=$fqname
 outDir+="_rRNA_Mapped"

 #Get the full path of the fastq
 fullP=$1
 fullP+="/"
 fullP+=$f

 #Execute blat_engine_indivFQ on each fastq
 echo "Running blat_engine_indivFQ on $f-----------"
 $indivEx $fullP $2 $3 $4 

 #Run star on the unmapped reads in the unmapped.fastq
 #Get the full path of the input unmapped fastq
 unmP=$outDir
 unmP+=/unmapped.fastq
 #Get the name of the STAR output
 starOut=$outDir
 starOut+="/STAR_Unmapped"
 mkdir $starOut
 #Save the picard output name
 picardIn=$starOut
 picardIn+="/STAR_Aligned.out.sam"
 starOut+="/STAR_"

 #Actually run the alignment
 echo "Running STAR on $unmP"
 STAR --genomeDir $6 --readFilesIn $unmP --outFileNamePrefix $starOut

 #Run picard tools collectRNAseq on the alignment file from the unmapped category
 #Output file
 picardOut=$outDir
 picardOut+="/unmapped_picard_output.txt"
 
 #Running picard
 java -jar $8 CollectRnaSeqMetrics I=$picardIn O=$picardOut REF_FLAT=$7 STRAND=NONE

done

#Run the collection program

