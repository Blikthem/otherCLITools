#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 12:03:24 2020

@author: claypooldj
"""
import pandas as pd
import os
from plotly.offline import plot
from plotly import graph_objs as go

#Inputs------------------------------------------------------------------------------------
"""
inpkMerCSV="/Volumes/Untitled/Output/kMerBackground/testDitto_2/PTBP1_AllClusters_v_backgroundMimic_kMers.csv"
inputDirectory="/Volumes/Untitled/Output/kMerBackground/testDitto/withOldBackground/ToVisualize"
outputDirectory="/Volumes/Untitled/Output/kMerBackground/testDitto_2"
"""
#------------------------------------------------------------------------------------

#Functions------------------------------------------------------------------------------------
def getGraphDF(inpDF):
    """
    Takes a raw dataframe from visualizeZScores output and reformats it for graphing ease.
    Input/output:
        pandas data frame
    """
    ACount=[]
    UCount=[]
    CCount=[]
    GCount=[]
    purineCount=[]
    pyrimidineCount=[]
    for index, row in inpDF.iterrows():
        thekMer=row['kMer']
        ACount.append(thekMer.count("A"))
        UCount.append(thekMer.count("U"))
        CCount.append(thekMer.count("C"))
        GCount.append(thekMer.count("G"))
        purineCount.append(thekMer.count("A")+thekMer.count("G"))
        pyrimidineCount.append(thekMer.count("C")+thekMer.count("U"))
    inpDF['ACount']=ACount
    inpDF['UCount']=UCount
    inpDF['CCount']=CCount
    inpDF['GCount']=GCount
    inpDF['purineCount']=purineCount
    inpDF['pyrimidineCount']=pyrimidineCount
    
    return(inpDF)


def createInteractiveColorGraph(inpDF,outDir,fName):
    """
    Generates an interactive (html) graph which can be used to explore the distribution kMer output.
    Inputs:
        inpDF (pandas dataframe) - A dataframe including nucleotide counts.
        outDir (str) - The directory within which to save the interactive file.
        fName (str) - Name of the input file, used for saving.
    """
    xVals=inpDF["% reference clusters"]
    yVals=inpDF["% cluster read space"]
    hd=inpDF["kMer"]
    nHD=[]
    for val in hd:
        nVal="kMer: "
        nVal=nVal+val
        nHD.append(nVal)
    colorVals=inpDF["ACount"]
    colorVals2=inpDF["UCount"]
    colorVals3=inpDF["GCount"]
    colorVals4=inpDF["CCount"]
    colorVals5=inpDF['purineCount']
    colorVals6=inpDF['pyrimidineCount']

    layout = go.Layout(
            #paper_bgcolor='rgba(0,0,0,0)',
            #plot_bgcolor='rgba(0,0,0,0)'
    )
    
    fig = go.Figure(data=go.Scatter(x=xVals, y=yVals, mode='markers',hovertext=nHD,
        marker=dict(size=12,color="black")),layout=layout)

    
    fig.layout.update(
        updatemenus = [
            go.layout.Updatemenu(
                type = "dropdown", direction = "right", active = 0, x = 0.1, y = 1.2,
                buttons = list(
                        [
                        dict(
                        label = "All", method = "update", 
                        args = [{"marker": dict(size=12,color="black")}]
                        ),
                        dict(
                        label = "A Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals,colorscale=[(0,"white"), (1,"green")] ,showscale=True)}]
                        ),
                        dict(
                        label = "U Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals2,colorscale=[(0,"white"), (1,"red")],showscale=True)}]
                        ),
                        dict(
                        label = "C Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals4,colorscale=[(0,"white"), (1,"orange")],showscale=True)}]
                        ),
                        dict(
                        label = "G Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals3,colorscale=[(0,"white"), (1,"blue")],showscale=True)}]
                        ),
                        dict(
                        label = "Purine Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals5,colorscale=[(0,"white"), (1,"Purple")],showscale=True)}]
                        ),
                        dict(
                        label = "Pyrimidine Count", method = "update", 
                        args = [{"marker": dict(size=12, color=colorVals6,colorscale=[(0,"white"), (1,"Purple")],showscale=True)}]
                        )
                    ]
            )
            )
        ]    
    )
    
    fig.update_layout(
    title="kMer Distribution: "+fName,
    xaxis_title="% Reference Clusters",
    yaxis_title="% Cluster Read Space",
    font=dict(
        size=18
    )
)
    toSave=outDir+"/"+fName+"kMerDistribution_vsReference.html"
    plot(fig,filename=toSave)       
#------------------------------------------------------------------------------------

#Run------------------------------------------------------------------------------------
def run(kMerCSV,outDir):
    fName= os.path.basename(kMerCSV)
    fName2=os.path.splitext(fName)[0]
    
    #Load the data
    startingDF=pd.read_csv(kMerCSV)
    toGraph=getGraphDF(startingDF)
    
    #Graph the data
    createInteractiveColorGraph(toGraph,outDir,fName2)

def runOnAllInDir(inpDir,outDir):
    theFiles=os.listdir(inpDir)
    for inpF in theFiles:
        if ".csv" in inpF:
            toI=inpDir+"/"+inpF
            run(toI,outDir)

#run(inpkMerCSV,outputDirectory)