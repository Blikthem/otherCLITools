module load star/2.7.0a
module load python/3.7.2

#Inputs----------------------------------------------------------------------------
inputDir=$1
genomeDirectory=$2
refFlat=$3
picJar=$4
#----------------------------------------------------------------------------


#Run----------------------------------------------------------------------------
	#Change directories to one of interest
cd $inputDir

#1: Both Mapped --------------------------
	#Create output directory
outDir=$inputDir
outDir+=/bothMappedAnalysis
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/bothMapped_STAR_"

echo "Running alignment on mapped_inBoth FASTQs"
	#Run 
STAR --genomeDir $genomeDirectory --readFilesIn mapped_inBoth_R1.fastq mapped_inBoth_R2.fastq  --outFileNamePrefix $starOut

#Run picard tools collectRNAseq on the alignment file
picardIn=$outDir
picardIn+="/bothMapped_STAR_Aligned.out.sam"
	#Output file
picardOut=$outDir
picardOut+="/bothMapped_picard_output.txt"

#Running picard
java -jar $picJar CollectRnaSeqMetrics I=$picardIn O=$picardOut REF_FLAT=$refFlat STRAND=NONE

#Running picard visualization
python /home/claypooldj/rRNADepletion/blat/picardPie.py $picardOut $outDir 

#2: One Mapped --------------------------
        #Create output directory
outDir=$inputDir
outDir+=/oneMappedAnalysis
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/oneMapped_STAR_"

echo "Running alignment on mapped_inBoth FASTQs"
        #Run
STAR --genomeDir $genomeDirectory --readFilesIn mapped_inOne_R1.fastq mapped_inOne_R2.fastq  --outFileNamePrefix $starOut

#Run picard tools collectRNAseq on the alignment file
picardIn=$outDir
picardIn+="/oneMapped_STAR_Aligned.out.sam"
        #Output file
picardOut=$outDir
picardOut+="/oneMapped_picard_output.txt"

#Running picard
java -jar $picJar CollectRnaSeqMetrics I=$picardIn O=$picardOut REF_FLAT=$refFlat STRAND=NONE

#Running picard visualization
python /home/claypooldj/rRNADepletion/blat/picardPie.py $picardOut $outDir

#3: Neither Mapped --------------------------
        #Create output directory
outDir=$inputDir
outDir+=/neitherMappedAnalysis
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/neitherMapped_STAR_"

echo "Running alignment on mapped_inBoth FASTQs"
        #Run
STAR --genomeDir $genomeDirectory --readFilesIn mapped_notInBoth_R1.fastq mapped_notInBoth_R2.fastq  --outFileNamePrefix $starOut

#Run picard tools collectRNAseq on the alignment file
picardIn=$outDir
picardIn+="/neitherMapped_STAR_Aligned.out.sam"
        #Output file
picardOut=$outDir
picardOut+="/neitherMapped_picard_output.txt"

#Running picard
java -jar $picJar CollectRnaSeqMetrics I=$picardIn O=$picardOut REF_FLAT=$refFlat STRAND=NONE

#Running picard visualization
python /home/claypooldj/rRNADepletion/blat/picardPie.py $picardOut $outDir

#----------------------------------------------------------------------------
