/home/claypooldj/PCA_Pipeline/combineRSEM.sh /home/claypooldj/PCA_Pipeline/outDir/allGeneResults /home/claypooldj/PCA_Pipeline/outDir/
