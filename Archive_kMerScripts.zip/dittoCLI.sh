#Load dependencies--------------------
module load python/3.7.2
module load bedtools2/2.27.1

#Inputs--------------------------------
inputDir=$1
outputDir=$2

echo "Running kMer Ditto...."
echo Input directory:  $1
echo Output Directory:  $2

#CHANGEABLE PARAMETRS - Manually change them here _________________________
#Whether to generate ghost clusters from the same sub-gene regions or not
detectionMode="Auto" 
#Wheter to weight by read count
wbrc="True"
#Kmer length. Might work for higher values but really only tested for 5
kMerL=5
#----------------------------------------------------------

#Get the script dir
scriptDir="${0%/*}"

#GENOME FILES: MANUALLY CHANGE THESE IF YOU DON'T WANT HG38 _________________________
#Note: The longest transcript anotation was generated via the Shiloh toolkit metagene function
longestTranscriptAnot=$scriptDir
longestTranscriptAnot+=/gencode_hg38.longestTranscript.csv
wholeGenomeFasta=$scriptDir
wholeGenomeFasta+=/GRCh38.p12.genome.fa
#--------------------------------------

#Step 0: cd
mkdir -p $outputDir
cd $scriptDir

#Step 1: Generate bed files for ghost clusters
echo -n "Generating bed files..."
python dittoClusters_4_CLI.py $longestTranscriptAnot $inputDir $outputDir $detectionMode True
python dittoClusters_4_CLI.py $longestTranscriptAnot $inputDir $outputDir $detectionMode False

	#Establish the list of directories to run calculations in
cd $outputDir
outputSubs=""
for d in *_kMer_Output/ ; do
 toAdd=$outputDir
 toAdd+="/"
 toAdd+=$d
 outputSubs+=" "
 outputSubs+=$toAdd
done

for subDir in $outputSubs
do
 cd $subDir
 directoryName=${PWD##*/}
 toRem="_kMer_Output"
 filePrefix="${directoryName//$toRem/}"
 
 #Step 2: Convert bed files into fasta files using bedtools
 echo -n "Generating fasta files..."
 for file in *.bed
 do
  #Get output name
  filename="${file%%.*}"
  filename+=".fasta"
  echo $filename
  #Convert to fasta
  bedtools getfasta -fi $wholeGenomeFasta -bed $file -fo $filename
 done

 #Step 3: Generate the kMerZ option
 echo -n "Generating list of kMers to consider..."
 perl $scriptDir/kmer-set-maker.pl $kMerL > kMerReferences.txt

 #Step 4: Count kMers
 echo -n "Counting kMers ..."
 perl $scriptDir/kmer-counter.pl kMerReferences.txt ${filePrefix%%.*}_AllClusters.fasta ${filePrefix%%.*}_kMerCountsSeq_AllClusters.tsv
 perl $scriptDir/kmer-counter.pl kMerReferences.txt ${filePrefix%%.*}_backgroundMimic.fasta ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic.tsv
 perl $scriptDir/kmer-counter.pl kMerReferences.txt ${filePrefix%%.*}_backgroundMimic_wbrc.fasta ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic_wbrc.tsv
 perl $scriptDir/kmer-counter.pl kMerReferences.txt ${filePrefix%%.*}_clustersUsed.fasta ${filePrefix%%.*}_kMerCountsSeq_clustersUsed.tsv

 #Step 5: Calculate Z scores
 echo -n "Calculating Z scores ..."
 python $scriptDir/z-score_calculator_vMe.py ${filePrefix%%.*}_kMerCountsSeq_AllClusters.tsv ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic.tsv ${filePrefix%%.*}_kMerZScores_AllClusters_v_backgroundMimic.tsv
 python $scriptDir/z-score_calculator_vMe.py ${filePrefix%%.*}_kMerCountsSeq_AllClusters.tsv ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic_wbrc.tsv ${filePrefix%%.*}_kMerZScores_AllClusters_v_backgroundMimic_wbrc.tsv
 python $scriptDir/z-score_calculator_vMe.py ${filePrefix%%.*}_kMerCountsSeq_clustersUsed.tsv ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic.tsv ${filePrefix%%.*}_kMerZScores_clustersUsed_v_backgroundMimic.tsv
 python $scriptDir/z-score_calculator_vMe.py ${filePrefix%%.*}_kMerCountsSeq_clustersUsed.tsv ${filePrefix%%.*}_kMerCountsSeq_backgroundMimic_wbrc.tsv ${filePrefix%%.*}_kMerZScores_clustersUsed_v_backgroundMimic_wbrc.tsv

 #Step 6: Visualize the results and calculate within clusters
 echo -n "Visualize the results	and calculate within clusters..."
 cwd=$(pwd)
 python $scriptDir/visualizeZScores_CLI_Pipeline_v2.py $cwd ${filePrefix%%.*}_kMerZScores_AllClusters_v_backgroundMimic.tsv ${filePrefix%%.*}.csv $cwd $inputDir ${filePrefix%%.*}_clustersUsed.fasta
 python $scriptDir/visualizeZScores_CLI_Pipeline_v2.py $cwd ${filePrefix%%.*}_kMerZScores_AllClusters_v_backgroundMimic_wbrc.tsv ${filePrefix%%.*}.csv $cwd $inputDir ${filePrefix%%.*}_backgroundMimic_wbrc.fasta
 python $scriptDir/visualizeZScores_CLI_Pipeline_v2.py $cwd ${filePrefix%%.*}_kMerZScores_clustersUsed_v_backgroundMimic.tsv ${filePrefix%%.*}.csv $cwd $inputDir ${filePrefix%%.*}_clustersUsed.fasta
 python $scriptDir/visualizeZScores_CLI_Pipeline_v2.py $cwd ${filePrefix%%.*}_kMerZScores_clustersUsed_v_backgroundMimic_wbrc.tsv ${filePrefix%%.*}.csv $cwd $inputDir ${filePrefix%%.*}_backgroundMimic_wbrc.fasta
done


