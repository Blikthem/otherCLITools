#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 11:54:42 2020

@author: claypooldj
"""
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Load packages 
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import pandas as pd
import os
import random
from HeatMapper25_forDitto import anotGene
from HeatMapper25_forDitto import chromesome
from HeatMapper25_forDitto import anotFile
from HeatMapper25_forDitto import readInGTFFile
from HeatMapper25_forDitto import getCSV
from HeatMapper25_forDitto import cluster
#random.seed(5041995)

##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Inputs
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
inputDir="/Volumes/Untitled/Output/TestingCVC" #Directory containing the clusters.csv files to analyze
anotF="/Volumes/Untitled/Genomes/gencode_hg38.longestTranscript.csv"
outDir="/Volumes/Untitled/Output/kMerBackground/ghostClusters"
allowedRegions=["intron","TUTR","FUTR","CDS","exon","UTR"]
allowedRegions="Auto"
wbrcInput="False"
#inputDir="/Volumes/Untitled/Output/ClustersCombined_toUse"
"""
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Classes
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class PC:
    """
    PAR-CLIP Object: Represents a parclip in cluster terms.

    Properties:
        fileName (str) - Name of the cluster file form where this PC object was generated.
        geneDict (Dictionary) - Dictionary linking gene name with lists of cluster objects.
        allClusters (List) - Master list containing all clusters
    
    Methods:
        init - Initializer
        str - Conversion to string form for printing
        coversIndex - Checks if an index is within the anotation row object
    """
    def __init__(self, fileName,geneDict,allClusters):
        """
        Initalizing method.
        """
        self.fileName=fileName
        self.geneDict=geneDict
        self.allClusters=allClusters
        
    def __str__(self):
        """
        Returns a string that represents the object
        """
        toPrint="{PC Object} File: "+self.fileName+"\tNumber of clusters: "+str(len(self.allClusters))+"\tNumber of genes with clusters: "+str(len(self.geneDict))
        return(toPrint)
        
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Functions
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def is_int(val):
    try:
        num = int(val)
    except ValueError:
        return False
    return True

def createLstOfPCs(myDir):
    """
    Creates a list of parclip objects based on an input directory of cluster.csv files.
    Input:
        myDir(String) - File path to the directory containing all of the cluster.csv files to be inputs for the program or the name of a single clsuter.csv file to analyze.
    Returns:
        List[parclip] - A list of parclip objects representing the csv files in the directory.
    """ 
    #Set the wd to be myDir
    if ".csv" not in myDir:
        os.chdir(myDir)
    listOfParclipObjects = []
    
    #The files to be analyzed
    filesToAnalyze=[]
    if ".csv" in myDir:
        filesToAnalyze.append(myDir)
    elif ".csv" not in myDir:
        filesToAnalyze=os.listdir(myDir)
    
    #For each file in the directory
    for i in range(0,len(filesToAnalyze)):
        #Read in said file
        filename= filesToAnalyze[i]
        if ".csv" not in filename:
            continue
        if ".csv" not in myDir:
            toReadForCSV = myDir+"/"+filename
        if ".csv" in myDir:
            toReadForCSV=filename
        currentList = getCSV(toReadForCSV)
        
        #Copy the file into the 
        
        #Create a parclipobject with the name
            #Value: filename, geneDict, allclusters
        title = filename
        nTitle = title.replace('.csv', '')
        allTheClusters=[]
        geneDict={}
        
        #Parse over each dictionary in the list
        for cDict in currentList:
            #Take the cluster if it is a gene to be used or if there are no gene restrictions
            #Create the corresponding cluster object
                #Populatethe default values
            theGeneName=cDict.get("GeneName")
            if type(theGeneName)!=str:
                theGeneName=""
            theCS=cDict.get("ConversionSpecificity")
            if type(theCS)!=str and type(theCS)!=int:
                theCS=0
            theT2=cDict.get("T2Cfraction")
            if type(theT2)!=str and type(theT2)!=int:
                theT2=0
            theUR=cDict.get("UniqueReads")
            if type(theUR)!=str and type(theUR)!=int:
                theUR=0
            theRC=cDict.get("ReadCount")
            if type(theRC)!=str and type(theRC)!=int:
                theRC=0
            theAT=cDict.get("Aligned to")
            if type(theAT)!=str:
                theAT=""
            nClust = cluster(cDict.get("Chr"),cDict.get("Strand"),cDict.get("Start"),cDict.get("End"),theGeneName,theCS,theT2,theUR,theRC,cDict.get("ClusterSequence"),theAT)            
            #Type conversion for sorting
            nClust.RC=(nClust.RC)
            #Add it to the lsit of possible lusters
            allTheClusters.append(nClust)
            #Add to the dictionary
            if len(cDict.get("GeneName")) >2:
                if cDict.get("GeneName") in geneDict:
                    geneDict[cDict.get("GeneName")].append(nClust)
                else:
                    geneDict[cDict.get("GeneName")]=[nClust]
        nPC=PC(nTitle,geneDict,allTheClusters)
        listOfParclipObjects.append(nPC)
        
    return(listOfParclipObjects)
    
def getAnotDict(gtfFileName,mainChromosomesOnly):
    """
    Read in the gtf file csv file, returning an anotatedFile object
    Input:
        gtfFile(String) - Name of the csv file.
        onlyMain (bool) - Whether only the main chromosomes should be considered.
    Returns:
        anotFile - An annotation file object that contains the information from the annotation csv file.
    """ 
    myGTFObj = readInGTFFile(gtfFileName,mainChromosomesOnly)
    
    #Convert the gtf object to a dictionary keyeed to gene
    toRet={}
    for chrom in myGTFObj.lstOfChromosomesGenes:
        for anotG in chrom.lstOfAnotElements:
            toRet[anotG.gene]=anotG
    return(toRet)

def getRandomRangeWithin_indicesList(rangeSize,indicesList):
    """
    Gets a random window of entered length within a set of indices given as a list of lists.
    Inputs:
        rangeSize(int) - length of the window to get.
        indicesList(List[List[int]]) - List of indices lists.
    Returns:
        List[] - A list representing a random index within the windows.
    """
    #Find a window which cant contain the range
    loopEscape=0
    parentWindow=[]
    while True==True: 
        parentWindow=selectRangeFromList(indicesList)
        loopEscape=loopEscape+1
        if (parentWindow[1]-parentWindow[0])==rangeSize:
            #print("Default returning: ",[parentWindow[0],parentWindow[1]])
            return([parentWindow[0],parentWindow[1]])
        if (parentWindow[1]-parentWindow[0])>rangeSize:
            break
        if loopEscape==50:
            return(False)
    
    #Now select a random starting number within the window
    upperBound=parentWindow[1]-rangeSize
    #Get the random starting number
    randStart=random.randrange(parentWindow[0],upperBound,1)
    return([randStart,randStart+rangeSize])


def selectRangeFromList(indicesList):
    """
    Randomly selects a window from a list of windows, weighted by length of the window.
    Inputs:
        rangeSize(int) - length of the window to get.
        indicesList(List[List[int]]) - List of indices lists.
    Returns:
        List[] - A list representing a random index within the windows.
    """
    #Probability dictionary - maps a windowed list [key] to the range of random values associated with it (value)
    probDist={}
    #Get the total area of the space
    totalRange=0
    counter=0
    for indWindow in indicesList:
        counter=counter+1
        old=totalRange
        totalRange=totalRange+(indWindow[1]-indWindow[0]+1)
        probDist[counter]=[old,totalRange]
    
    #Now generate random index
    theChoice = random.randrange(totalRange)
    
    #And match it to the cooresponding window
    for i in probDist.keys():
        theWindow=probDist[i]
        if numInRange_Inclusive(theChoice,theWindow)==True:
            return(indicesList[i-1])

def numInRange_Inclusive(num,ran):
    start=ran[0]
    stop=ran[1]
    
    if start<=num and num<stop:
        return(True)
    else:
        return(False)
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Run
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def run(anotF,inputCSVDirectory,outputDirectory,geneRegions,wByRC):
    """
    Generate a fasta background relative to PAR-CLIP in which ghost clusters are generated to mirror each individual PAR-CLIP cluster.
    Input:
        anotF(Str) - Annotation csv file to be read in (longest transcript varient)
        inputDirectoryCSV(Str) - Directory of csv files containing cluster information to be read in.
        outputDirectory (Str) - Directory where output files are deposited.
        geneRegions(list[str]) - The gene regions that are considered options from which random clusters can be drawn. Auto for matching with cluster annotation.
        wByRC (bool) - Should the number of ghost clusters generated per cluster linearly scale to the number of cross linked reads aligned to that cluster?
    """
    #Read in the annotation file
    print("Loading gtf longest annotation file...")
    anotDict=getAnotDict(anotF,True)
    print("...loaded.")
    
    #Read in the cluster.csv files
    print("Loading csv files...")
    PCDict=createLstOfPCs(inputCSVDirectory)
    print("...loaded.")
    
    print("wByRC: ",wByRC)

    #Run the comparison
    for indPC in PCDict:
        #Create a new subdirectory to store the output files
        nSubDir=outputDirectory+"/"+indPC.fileName+"_kMer_Output"
        if not os.path.exists(nSubDir):
            os.mkdir(nSubDir)
        toRet=[]
        #Create a to return for the original cluster used to generate ghosts.
        toRet2=[]
        for cGene in indPC.geneDict.keys():
            #For each cluster
            for clust in indPC.geneDict[cGene]:
                if cGene not in anotDict:
                    continue
                #Create a sequence
                #Establish the regions to consider
                if geneRegions=="Auto":
                    rtUse=clust.alignedTo
                else:
                    rtUse=geneRegions
                
                #Check that the gene has area in these regions, otherwise you will have continue through the process
                checker=anotDict[cGene].getGeneRegionBounds(rtUse)
                if len(checker)==0:
                    continue

                #Save cluster id to add if need be
                addToControl=False
                toAddToControl=[clust.chrom,clust.start,int(clust.end)+1]
                
                #Decide how many clusters to make
                numGhostClusters=1
                if wByRC=="True":
                    if is_int(clust.RC)==True:
                        numGhostClusters=int(clust.RC)
                    else:
                        numGhostClusters=1
                for i in range(0,numGhostClusters):
                    #Create a cluster for each weight of wByRC
                    theRange=getRandomRangeWithin_indicesList(len(clust.seq),anotDict[cGene].getGeneRegionBounds(rtUse))
                    if theRange==False:
                        continue
                    #Write to the growing bed file
                    else:
                        toRet.append([clust.chrom,theRange[0],theRange[1]])
                        addToControl=True
                if addToControl==True:
                    toRet2.append(toAddToControl)
        #Save various files
            #The raw cluster file
        toRet3=[]
        for indClust in indPC.allClusters:
            toRet3.append([indClust.chrom,indClust.start,int(indClust.end)+1])
        toRet3DF=pd.DataFrame(toRet3)
        toSave3=nSubDir+"/"+indPC.fileName+"_AllClusters.bed"
        toRet3DF.to_csv(toSave3,sep='\t', index=False,header=False)            
            
            #The cluster-match file
        toRet2DF=pd.DataFrame(toRet2)
        toSave2=nSubDir+"/"+indPC.fileName+"_clustersUsed.bed"
        toRet2DF.to_csv(toSave2,sep='\t', index=False,header=False)
            
            #The background
        toRetDF=pd.DataFrame(toRet)
        if wByRC=="True":
            toSave=nSubDir+"/"+indPC.fileName+"_backgroundMimic_wbrc.bed"
        else:
            toSave=nSubDir+"/"+indPC.fileName+"_backgroundMimic.bed"
        toRetDF.to_csv(toSave,sep='\t', index=False,header=False)
            
#run(anotF,inputDir,outDir,allowedRegions,wbrcInput)