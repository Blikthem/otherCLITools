#RNASeq for server run
#Takes in two parameters:
#-------------------------------------------------------------
#Input 1 - Input file (the expression values by sample)
#Input 2 - Output directory (the directory to output files to)
#-------------------------------------------------------------
args = commandArgs(trailingOnly=TRUE)

print("Running PCA on: ")
print(args[1])
print("and outputing the results into: ")
print(args[2])

#Read in the data
highexprgenes_counts <- read.csv(file=args[1], header=TRUE, sep=",")
# transpose the data to have variables (genes) as columns
data_for_PCA <- t(highexprgenes_counts)

myDistMat<-dist(data_for_PCA)
print("------Dist matrix")
print((myDistMat))
## calculate MDS (matrix of dissimilarities)
mds <- cmdscale(myDistMat, k=3, eig=TRUE)  

# transform the Eigen values into percentage
eig_pc <- mds$eig * 100 / sum(mds$eig)

varianceExplained <- data.frame("Explained Varience(%)" = eig_pc)
#rownames(varianceExplained) <- NULL
print(varianceExplained)
write.csv(varianceExplained,paste(args[2],"/explained_Varience.csv",sep=''))

## calculate MDS
mds <- cmdscale(dist(data_for_PCA)) # Performs MDS analysis 
x<-(mds[,1])
y<-(mds[,2])
print(mds)

#Convert to a usable data format
df <- as.data.frame(mds)
colnames(df)=c("Dimension1","Dimension2")
print(df)
write.csv(df,paste(args[2],"/PCA_Matrix.csv",sep=''))

