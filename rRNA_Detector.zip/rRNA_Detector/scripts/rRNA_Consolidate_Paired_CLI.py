#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 15:37:10 2020

@author: claypooldj
"""
#Import dependencies 
from FASTQ_Reader import readFASTQ
import pandas as pd
import sys
#Inputs------------------------------------------------------------------------------------------------
inpDir1=sys.argv[1]
inpDir2=sys.argv[2]
outputDir=sys.argv[3]
#-------------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------------------------
#Functions------------------------------------------------------------------------------------------------
def intersection(lst1, lst2): 
    return list(set(lst1) & set(lst2)) 
def consolidateFASTQs(directory1,directory2,outDir):
    """
    Inputs:
        Directory1 (Str) - Directory with R1 unmapped.fastq and mapped.fastq
        Directory2 (Str) - Directory with R2 unmapped.fastq and mapped.fastq
    Output:
        
    """
    #Read in the fastq files (Four of them)
        #R1
    FASTQ_DictR1_Mapped=readFASTQ(directory1+"/mapped.fastq","Dictionary")
    FASTQ_DictR1_Unmapped=readFASTQ(directory1+"/unmapped.fastq","Dictionary")
        #R2
    FASTQ_DictR2_Mapped=readFASTQ(directory2+"/mapped.fastq","Dictionary")
    FASTQ_DictR2_Unmapped=readFASTQ(directory2+"/unmapped.fastq","Dictionary")
    
    #Initialize the text files to write to with hits
    inBoth_R1=open(outDir+"/mapped_inBoth_R1.fastq","w+")
    inBoth_R2=open(outDir+"/mapped_inBoth_R2.fastq","w+")
    inOne_R1=open(outDir+"/mapped_inOne_R1.fastq","w+")
    inOne_R2=open(outDir+"/mapped_inOne_R2.fastq","w+")
    
    #Initialize the text files to write to with empties
    notInBoth_R1=open(outDir+"/mapped_notInBoth_R1.fastq","w+")
    notInBoth_R2=open(outDir+"/mapped_notInBoth_R2.fastq","w+")
    
        #In R1 but not in R2
    inR1_notR2_mapped=open(outDir+"/inR1_notR2_mapped.fastq","w+")
    inR1_notR2_unmapped=open(outDir+"/inR1_notR2_unmapped.fastq","w+")
    inR2_notR1_mapped=open(outDir+"/inR2_notR1_mapped.fastq","w+")
    inR2_notR1_unmapped=open(outDir+"/inR2_notR1_unmapped.fastq","w+")
    
        #In R2 but not in R1
    #Create lists which will store the headers for counting purposes
    bothMapped_Headers=[]
    neitherMapped_Headers=[]
    inOneOnly_Headers=[]
    inR1_notR2_Headers=[]
    inR2_notR1_Headers=[]
    inR1_notR2_Headers_mapped=[]
    inR1_notR2_Headers_unmapped=[]
    inR2_notR1_Headers_mapped=[]
    inR2_notR1_Headers_unmapped=[]
    
    #Acquire those sequence headers not found in both fastq files
    R1Headers=list(FASTQ_DictR1_Mapped.keys())+list(FASTQ_DictR1_Unmapped.keys())
    R2Headers=list(FASTQ_DictR2_Mapped.keys())+list(FASTQ_DictR2_Unmapped.keys())
    
    
    overlappingHeaders=intersection(R2Headers,R1Headers) 
    
    inR1_notR2_Headers=list(set(R1Headers).difference(overlappingHeaders))
    inR2_notR1_Headers=list(set(R2Headers).difference(overlappingHeaders))

    #Loop over the individual sequences
        #In the singles
    #for header in inR1_not_R2_Headers
    for val1 in inR1_notR2_Headers:
        if val1 in FASTQ_DictR1_Mapped:
            inR1_notR2_mapped.write(FASTQ_DictR1_Mapped[val1].toWrite())
            inR1_notR2_Headers_mapped.append(val1)
        else:
            inR1_notR2_unmapped.write(FASTQ_DictR1_Unmapped[val1].toWrite())
            inR1_notR2_Headers_unmapped.append(val1)

    #for header in inR2_not_R1_Headers
    for val1 in inR2_notR1_Headers:
        if val1 in FASTQ_DictR2_Mapped:
            inR2_notR1_mapped.write(FASTQ_DictR2_Mapped[val1].toWrite())
            inR2_notR1_Headers_mapped.append(val1)
        else:
            inR2_notR1_unmapped.write(FASTQ_DictR2_Unmapped[val1].toWrite())
            inR2_notR1_Headers_unmapped.append(val1)
	
    #Loop over the sequences
    for header in overlappingHeaders:            
            
        #Check if it is mapped to both
        if header in FASTQ_DictR1_Mapped and header in FASTQ_DictR2_Mapped:
            inBoth_R1.write(FASTQ_DictR1_Mapped[header].toWrite())
            inBoth_R2.write(FASTQ_DictR2_Mapped[header].toWrite())
                
            inOne_R1.write(FASTQ_DictR1_Mapped[header].toWrite())
            inOne_R2.write(FASTQ_DictR2_Mapped[header].toWrite())
            
            bothMapped_Headers.append(header)

        else:
            
            #If in neither
            if header not in FASTQ_DictR1_Mapped and header not in FASTQ_DictR2_Mapped:
                notInBoth_R1.write(FASTQ_DictR1_Unmapped[header].toWrite())
                notInBoth_R2.write(FASTQ_DictR2_Unmapped[header].toWrite())
                    
                neitherMapped_Headers.append(header)
            
            #Check if mapped to only one
            if header in FASTQ_DictR1_Mapped:
                inOne_R1.write(FASTQ_DictR1_Mapped[header].toWrite())
                inOne_R2.write(FASTQ_DictR2_Unmapped[header].toWrite())
                    
                notInBoth_R1.write(FASTQ_DictR1_Mapped[header].toWrite())
                notInBoth_R2.write(FASTQ_DictR2_Unmapped[header].toWrite())
                
                inOneOnly_Headers.append(header)
                    
                
            if header in FASTQ_DictR2_Mapped:
                inOne_R1.write(FASTQ_DictR1_Unmapped[header].toWrite())
                inOne_R2.write(FASTQ_DictR2_Mapped[header].toWrite())
                    
                notInBoth_R1.write(FASTQ_DictR1_Unmapped[header].toWrite())
                notInBoth_R2.write(FASTQ_DictR2_Mapped[header].toWrite())
                
                inOneOnly_Headers.append(header)
    
    
    for f in [inBoth_R1,inBoth_R2,inOne_R1,inOne_R2,notInBoth_R1,notInBoth_R2,inR1_notR2_mapped,inR1_notR2_unmapped,inR2_notR1_mapped,inR2_notR1_unmapped]:
        f.close()
    
    totalReads=float(len(bothMapped_Headers)+len(inOneOnly_Headers)+len(neitherMapped_Headers))
    percent_BothMapped=100.0*len(bothMapped_Headers)/totalReads
    percent_SingleMapped=100.0*len(inOneOnly_Headers)/totalReads
    percent_NeitherMapped=100.0*len(neitherMapped_Headers)/totalReads
    
    #Save count summary to csv file
    forCSV=[]
    forCSV.append(["In R1 but not R2",len(inR1_notR2_Headers)])
    forCSV.append(["Mapped: ",len(inR1_notR2_Headers_mapped)])
    forCSV.append(["Unmapped: ",len(inR1_notR2_Headers_unmapped)])
    forCSV.append(["In R2 but not R1",len(inR2_notR1_Headers)])
    forCSV.append(["Mapped",len(inR2_notR1_Headers_mapped)])
    forCSV.append(["Unmapped",len(inR2_notR1_Headers_unmapped)])
    forCSV.append(["Both mapped",len(bothMapped_Headers)])
    forCSV.append(["Only one mapped",len(inOneOnly_Headers)])
    forCSV.append(["Neither mapped",len(neitherMapped_Headers)])
    forCSV.append(["Both apped %",percent_BothMapped])
    forCSV.append(["Only one mapped %",percent_SingleMapped])
    forCSV.append(["Neither mapped %",percent_NeitherMapped])
    toOut=pd.DataFrame(forCSV)
    toOut.to_csv(outDir+"/countSummary.csv",index=False,header=False)
    
    
    print("In R1 but not R2: ",len(inR1_notR2_Headers))
    print("\t Mapped: "+str(len(inR1_notR2_Headers_mapped)))
    print("\t Unmapped: "+str(len(inR1_notR2_Headers_unmapped)))
    print("In R2 but not R1: ",len(inR2_notR1_Headers))
    print("\t Mapped: "+str(len(inR2_notR1_Headers_mapped)))
    print("\t Unmapped: "+str(len(inR2_notR1_Headers_unmapped)))
    print("Both mapped: ",len(bothMapped_Headers))
    print("Only one mapped: ",len(inOneOnly_Headers))
    print("Neither mapped: ",len(neitherMapped_Headers))
    print("Both mapped %: ",percent_BothMapped)
    print("Only one mapped %: ",percent_SingleMapped)
    print("Neither mapped %: ",percent_NeitherMapped)
#-------------------------------------------------------------------------------------------------------
#Run------------------------------------------------------------------------------------------------
def run(inpDirectory1,inpDirectory2,out):
    consolidateFASTQs(inpDirectory1,inpDirectory2,out)

run(inpDir1,inpDir2,outputDir)
