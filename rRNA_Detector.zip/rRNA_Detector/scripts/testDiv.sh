var1=8
var2=4
echo $((var1 / var2))
