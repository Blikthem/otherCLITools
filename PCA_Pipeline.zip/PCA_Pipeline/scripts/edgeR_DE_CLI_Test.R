library(edgeR)
#Input Parameters----------------------------
#Enter the expression matrix to be used for the differential expression calculations
args = commandArgs(trailingOnly=TRUE)
print("Here")
inputMatrix<-args[1]
#Set the groups by their column indices
#New---
toUse<-args[2]

#Replace ]'s with )s in string
print(toUse)
toUse=gsub("[", "", toUse, fixed=TRUE)
toUse=gsub("]", "", toUse, fixed=TRUE)
group=as.list(strsplit(toUse, ","))[[1]]
print("Groups to use: ")
print(group)
#---
#OLD---
#toUse<args[2]
#group=as.list(strsplit(toUse, ","))[[1]]
#print(group)
#---

#Output directory
outDir<-args[3]
#-------------------------------------------
#CALCULATION 1 - RUN WITH TMM NORMALIZATION AND SAVE OUTPUT--------------
#Step 1 - Read in the expression matrix to an object in R 
gmat<-read.table(file = inputMatrix, sep = '\t', header = TRUE,row.names ='X')
print("Got the expression matrix into R object")
print(names(gmat))
group2=c(1, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
  
#Step 2 - Save this gene matrix to an edgeR data type (DGEList), incorperating the groups input
dgList<-DGEList(counts=gmat,group=group)
print("Saved to edgeR data type")
print(dgList)
#Step 3 - Filter out lowly expressed genes from the matrix
print("Check before keep")
keep <- filterByExpr(dgList,group=group2)
print(typeof(keep))
print(keep)
dgList <- dgList[keep, , keep.lib.sizes=FALSE]
print("Filtered out lowly expressed genes")
print(dgList)

# #Step 4 - Perform TMM normalization
# dgList <- calcNormFactors(dgList,doWeighting=TRUE)
# dgList$samples
# 
# #Step 5 - Create the model matrix
# design <- model.matrix(~group)
# 
# #Step 6 - estimate dispersion
# dgList <- estimateDisp(dgList,design)
# 
# #Step 7 - Fit the model 
# fit <- glmQLFit(dgList, design)
# 
# #Step 8 - Perform differential expression on data using the dispersion and TMM normalization values generated above
# qlf <- glmQLFTest(fit, coef=2)
# #Step 9 - Write differential expression to csv file.
# toSave<-paste(outDir,"/DiffExpTest_TMM.csv",sep='')
# write.csv(qlf$table,toSave)
# 
# #CALCULATION 2 - RUN WITHOUT TMM NORMALIZATION AND SAVE OUTPUT--------------
# #Step 1 - Read in the expression matrix to an object in R 
# gmat<-read.table(file = inputMatrix, sep = '\t', header = TRUE,row.names ='X')
# 
# #Step 2 - Save this gene matrix to an edgeR data type (DGEList), incorperating hte groups input
# dgList<-DGEList(counts=gmat,group=group)
# 
# #Step 3 - Filter out lowly expressed genes from the matrix
# keep <- filterByExpr(dgList)
# dgList <- dgList[keep, , keep.lib.sizes=FALSE]
# 
# #Step 5 - Create the model matrix
# design <- model.matrix(~group)
# 
# #Step 6 - estimate dispersion
# dgList <- estimateDisp(dgList,design)
# 
# #Step 7 - Fit the model 
# fit <- glmQLFit(dgList, design)
# 
# #Step 8 - Perform differential expression on data using the dispersion and TMM normalization values generated above
# qlf <- glmQLFTest(fit, coef=2)
# 
# #Step 9 - Write differential expression to csv file.
# toSave2<-paste(outDir,"/DiffExpTest_NoTMM.csv",sep='')
# write.csv(qlf$table,toSave2)
