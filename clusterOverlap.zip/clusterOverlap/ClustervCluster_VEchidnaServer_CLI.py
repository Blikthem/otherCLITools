#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: claypooldj
"""
###Load packages 
import csv
import os
import argparse

#Names of files
lstOfFileNames = []
clustNumsOfFiles = []
readNumsOfFiles = []



#Create a class for the combined list
class cvcLst:
     def __init__(self):
         self.names=lstOfFileNames
         self.nClusts=clustNumsOfFiles
         self.nReads=readNumsOfFiles
         self.combinedListofLists = []
         self.indicesLst=[]

#Sorts the lists in the object
     def sort(self):
         #We will be sorting by cluster numbers list
         #Convert it into a tuples to store the original position
         lstClustLsts = []
         for i in range(0,len(self.names)):
             nam = self.names[i]
             nCl = self.nClusts[i]
             nRe = self.nReads[i]
             #Create a list with index and values
             nLst = [i,nam,nCl,nRe]
             lstClustLsts.append(nLst)
        
        #
         print("original file order:")
         for w in lstClustLsts:
             print(w[1],"   ",w[2])
        
        
        #now we need to sort that tuple list  by the second entry
         lstClustLsts = sorted(lstClustLsts, key=lambda x: x[2])
         #Now set the values for the stored lists
         for i in range(0,len(lstClustLsts)):
             curL = lstClustLsts[i]
             self.names[i] = curL[1]
             self.nClusts[i]= curL[2]
             self.nReads[i]=curL[3]
             self.indicesLst.append(curL[0])    
         print("Sorted names: ")
         for n in self.names:
             print(n)
                  
                  

###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
###This function takes in a directory and file name and creates a dictionary of lists. Dictionary values correspond to columns and list enteries correspond to rows
def getCSV (myDir,myFile):
    #Changing the working directory
    wd = myDir
    os.chdir(wd)

    #Upload CSV using the CSV package and an instantiated CSV object
    readCSV = csv.DictReader(open(myFile))
    #Create the master list to be populated
    master_list = []

    
    #poulate this list by grabbing ordered dictionaries
    for line in readCSV:
        master_list.append(line)

    return(master_list)
    

###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##This function will take in a directory name and will return a list of dictionary lists, each corresponding to a file read in, the individual dictionaries represent rows
##Must add to a list each file name to be accessed later
def makeListofDictionaries (myDir,toInclude):
    #Set the wd to be myDir
    os.chdir(myDir)
    listOfDictionaryLists = []
    #For each file in the directory
    for i in range(0,len(os.listdir(myDir))):
        #Read in said file
        filename= os.listdir(myDir)[i]
        currentList = getCSV(myDir,filename)
        #Get the title
        title = filename
        nTitle = title.replace('.csv', '')
        #Add the title to the lst of file names
        lstOfFileNames.append(nTitle)
        
        #NUMBER OF READS MUST BE FOUND ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #Get the number of clusters 
        #For each key to be included
        totcount =0
        totReadCount=0
        for ke in toInclude:
            #Find out the number of ke matches
            countMatches = getNumClustersByName(currentList,ke)
            #Add this number to the total number of cluster matches
            totcount= totcount+countMatches
            #Add the read count to the total number of read counts
            numReads = getNumReadsByName(currentList,ke)
            totReadCount=totReadCount+numReads
            
        #Add this as the new totals
        clustNumsOfFiles.append(totcount)
        readNumsOfFiles.append(totReadCount)
        #Add to a master list
        listOfDictionaryLists.append(currentList)
    return (listOfDictionaryLists)


#This function takes in a list of dictionaries (clusters), a cluster tag for RNA target type, and returns the number of reads associated with that tag.
def getNumClustersByName (lstOfDict,tag):
    #For each row
    counter=0
    for r in range(0,len(lstOfDict)):
        #Get the cluster
        clust = lstOfDict[r]
        #Get the associated tag
        aTag = clust.get("Aligned to")
        #If it is the tag needed
        if aTag==tag:
            counter=counter+1
    return counter

##NEW FUNCTION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#This function takes in a list of dictionaries (clusters), a cluster tag for RNA target type, and returns the number of clusters associated with that tag.
def getNumReadsByName (lstOfDict,tag):
    #For each row
    counter=0
    for r in range(0,len(lstOfDict)):
        #Get the cluster
        clust = lstOfDict[r]
        #Get the associated tag
        aTag = clust.get("Aligned to")
        #If it is the tag needed
        if aTag==tag:
            counter=counter+int(clust.get("ReadCount"))
    return counter

###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##This function will take in a list of dictionary lists - representing individual files - and will return a list (files) of lists (Chromosomes) of tuple lists (RNA type).
##Individual tuples are clusters and the lists that hold them correspond to chromosomes
##First values (start) used to sort and second (end) kept
    #####ALSO INCLUDE A LIST INPUT WHICH TELLS THE USER WHICH TYPES OF RNA TARGET SECTIONS TO INCLUDE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convertToBins (lstOfDictionaries,toInclude):
    #Initiate the master list to return
    masterList = []

    #For each file
    for fl in lstOfDictionaries:   
        #Create the ugly number of chromosome bins
        chr1 = []
        chr2 = []
        chr3 = []
        chr4 = []
        chr5 = []
        chr6 = []
        chr7 = []
        chr8 = []
        chr9 = []
        chr10 = []
        chr11 = []
        chr12 = []
        chr13 = []
        chr14 = []
        chr15 = []
        chr16 = []
        chr17 = []
        chr18 = []
        chr19 = []
        chr20 = []
        chr21 = []
        chr22 = []
        chrX = []
        chrY = []

        for cuD in fl:
            #Current chr
            curChr = cuD.get("Chr")
            #Now we need to sort this new character and put it in the correct bin [Because it is a finite number of chromosomes this is going to get ugly. Sorry world.]
            if (curChr == "chr1"):
                chr1.append(cuD)
            if (curChr == "chr2"):
                chr2.append(cuD)
            if (curChr == "chr3"):
                chr3.append(cuD)
            if (curChr == "chr4"):
                chr4.append(cuD)
            if (curChr == "chr5"):
                chr5.append(cuD)
            if (curChr == "chr6"):
                chr6.append(cuD)
            if (curChr == "chr7"):
                chr7.append(cuD)
            if (curChr == "chr8"):
                chr8.append(cuD)
            if (curChr == "chr9"):
                chr9.append(cuD)
            if (curChr == "chr10"):
                chr10.append(cuD)
            if (curChr == "chr11"):
                chr11.append(cuD)  
            if (curChr == "chr12"):
                chr12.append(cuD)  
            if (curChr == "chr13"):
                chr13.append(cuD)  
            if (curChr == "chr14"):
                chr14.append(cuD)  
            if (curChr == "chr15"):
                chr15.append(cuD)  
            if (curChr == "chr16"):
                chr16.append(cuD)  
            if (curChr == "chr17"):
                chr17.append(cuD)  
            if (curChr == "chr18"):
                chr18.append(cuD)  
            if (curChr == "chr19"):
                chr19.append(cuD)  
            if (curChr == "chr20"):
                chr20.append(cuD)  
            if (curChr == "chr21"):
                chr21.append(cuD)  
            if (curChr == "chr22"):
                chr22.append(cuD)                  
            if (curChr == "chrX"):
                chrX.append(cuD)
            if (curChr == "chrY"):
                chrY.append(cuD)          
                
        #Create the new list structure that will replace the unordered list of dictionaries    
        ordLstOfDict2 =[]
        ordLstOfDict = [chr1,chr2,chr3,chr4,chr5,chr6,chr7,chr8,chr9,chr10,chr11,chr12,chr13,chr14,chr15,chr16,chr17,chr18,chr19,chr20,chr21,chr22,chrX,chrY]  
       
            #For each chrom in the list of bins
        for chrom in ordLstOfDict:
            #Create the requisite lists to be filled (again grossly by hand)
            grp_3_prime = []
            grp_5_prime = []
            grp_intron=[]
            grp_NA=[]
            grp_coding=[]
            grp_stp = []
            grp_antiS = []
            grp_PP = []
            grp_pTrans = []
            grp_ICoding = []
            grp_strt = []
            grp_linc = []
            grp_tec = []
            grp_UP = []
            grp_tpp = []
            grp_tup = []
            grp_sno = []
            grp_codI = []
            grp_lincE = []
            grp_mac = []
            grp_miR = []
            grp_misc = []
            grp_Mt = []
            grp_tMt = []
            grp_retI = []
            grp_SI = []
            grp_over = []
            grp_snR = []
            grp_unit = []
            
            #For each entry in that chromosome
            for ent in chrom:
                #Get the related type
                curT = ent.get("Aligned to")
                #Sort into bins
                if (curT == "3'utr"):
                    if "3'utr" in toInclude:
                        grp_3_prime.append(ent)
                    
                if (curT == "5'utr"):
                    if "5'utr" in toInclude:
                        grp_5_prime.append(ent)                   
                    
                if (curT == "intron"):
                    if "intron" in toInclude:
                        grp_intron.append(ent)

                if (curT == "NoAnnotation"):
                    if "NoAnnotation" in toInclude:
                        grp_NA.append(ent)

                if (curT == "coding"):
                    if "coding" in toInclude:
                        grp_coding.append(ent)
                    
                if (curT == "stop_codon"):
                    if "stop_codon" in toInclude:
                        grp_stp.append(ent)               
                
                if (curT == "antisense"):
                    if "antisense" in toInclude:
                        grp_antiS.append(ent)
                    
                if (curT == "processed_pseudogene"):
                    if "processed_pseudogene" in toInclude:
                        grp_PP.append(ent)  

                if (curT == "processed_transcript"):
                    if "processed_transcript" in toInclude:
                        grp_pTrans.append(ent)  

                if (curT == "intron-coding"):
                    if "intron-coding" in toInclude:
                        grp_ICoding.append(ent)        
                    
                if (curT == "start_codon"):
                    if "start_codon" in toInclude:
                        grp_strt.append(ent) 
                    
                if (curT == "lincRNA_intron"):
                    if "lincRNA_intron" in toInclude:
                        grp_linc.append(ent) 
                    
                if (curT == "TEC"):
                    if "TEC" in toInclude:                    
                        grp_tec.append(ent) 
                
                if (curT == "unprocessed_pseudogene"):
                    if "unprocessed_pseudogene" in toInclude:
                        grp_UP.append(ent) 
                    
                if (curT == "transcribed_processed_pseudogene"):
                    if "transcribed_processed_pseudogene" in toInclude:
                        grp_tpp.append(ent) 
                    
                if (curT == "transcribed_unprocessed_pseudogene"):
                    if "transcribed_unprocessed_pseudogene" in toInclude:
                        grp_tup.append(ent) 
                    
                if (curT == "snoRNA"):
                    if "snoRNA" in toInclude:
                        grp_sno.append(ent) 
                    
                if (curT == "coding-intron"):
                    if "coding-intron" in toInclude:
                        grp_codI.append(ent) 
                
                if (curT == "lincRNA_exon"):
                    if "lincRNA_exon" in toInclude:
                        grp_lincE.append(ent) 
                    
                if (curT == "macro_lncRNA"):
                    if "macro_lncRNA" in toInclude:
                        grp_mac.append(ent)
                
                if (curT == "miRNA"):
                    if "miRNA" in toInclude:
                        grp_miR.append(ent)
                    
                if (curT == "misc_RNA"):
                    grp_misc.append(ent)
                    
                if (curT == "Mt_rRNA"):
                    if "Mt_rRNA" in toInclude:
                        grp_Mt.append(ent)

                if (curT == "Mt_tRNA"):
                    if "Mt_tRNA" in toInclude:
                        grp_tMt.append(ent)

                if (curT == "retained_intron"):
                    if "retained_intron" in toInclude:
                        grp_retI.append(ent)
                
                if (curT == "sense_intronic"):
                    if "sense_intronic" in toInclude:
                        grp_SI.append(ent)

                if (curT == "sense_overlapping"):
                    if "sense_overlapping" in toInclude:
                        grp_over.append(ent)

                if (curT == "snRNA"):
                    if "snRNA" in toInclude:
                        grp_snR.append(ent)

                if (curT == "unitary_pseudogene"):
                    if "unitary_pseudogene" in toInclude:
                        grp_unit.append(ent)
                    
            #Create an empty list to hold the lists of target rna types
            lstByType = [grp_3_prime,grp_5_prime,grp_intron,grp_NA,grp_coding,grp_stp,grp_antiS,grp_PP,grp_pTrans,grp_ICoding,grp_strt,grp_linc,grp_tec,grp_UP,grp_tpp,grp_tup,grp_sno,grp_codI,grp_lincE,grp_mac,grp_miR,grp_misc,grp_Mt,grp_tMt,grp_retI,grp_SI,grp_over,grp_snR,grp_unit]
            
                    
             #Sort into tuples
            lstByType2 = []
            for cDict in lstByType:
                checker = sortDictByStart(cDict)
                #Add the soted tuples to the new lystbytype
                lstByType2.append(checker)
        
            #Replace the chromosome dictionary with a list of these values in a new ordlist of dictionaries
            ordLstOfDict2.append(lstByType2)
        masterList.append(ordLstOfDict2)
        
    return(masterList)
        
    
    
###Test
def getNumClustsTester(file):
    counter=0
    for chrom in file:
        #Get each type
        for typ in chrom:
            if typ:
                for i in range(0,len(typ)):
                    counter=counter+1
    return(counter)
    
###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
###Check whether two tuples (clusters) physically overalap
### Take in two cluster tuples and returns a boolean
def clustMatch(clust1,clust2):
    #Get clust 1 values
    startC1 = clust1[0]
    endC1 = clust1[1]
    #Get clust2 values
    startC2 = clust2[0]
    endC2 = clust2[1]

    if startC2 >= startC1:
        if startC2 <= endC1:
            return("TRUE")
    
    if endC2 >= startC1:
        if endC2 <= endC1:
            return("TRUE")
    
    if startC2<=startC1:
        if endC2>=endC1:
            return("TRUE")
            
    return("FALSE")


###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

###Takes in a list of dictionaries and sorts them based upon their read start value
## Returns sorted list of tuples start, end
def sortDictByStart (lstDict):
    #Make a list of the tuples
    lstTuples = []
    for di in lstDict:
        #Convert that dictionary into a tuple
        starPlace = di.get('Start')
        endPlace = di.get('End')
        myTuple = (starPlace,endPlace)
        lstTuples.append(myTuple)

    #Sort the list
    sortedLst = sorted(lstTuples, key=lambda tup: tup[0])

    return(sortedLst)
    
###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Takes in a list of two files and returns the number of overlapping clusters between the two
##Input - two files which are lists of chromosome lists which are tuple lists
##Return - the number of clusters matched and the number of clusters run

def findMatchNum (f1,f2):
    #Select the larger and smaller
    lf1 = getNumClustsTester(f1)
    lf2 = getNumClustsTester(f2)
    
    if lf1>=lf2:
        file1=f2
        file2=f1
        
    if lf2>=lf1:
        file1=f1
        file2=f2
    
    totalCount = 0
    clust=0
    tcount=0
    lengs = 0
    #For file one get the chromosomes
    for i in range(0,len(file1)):
         chrom1 =file1[i]
         chrom2 = file2[i] 
         #For each chromosome get the target types
         for t in range(0,len(chrom1)):
             typ1 = chrom1[t]
             typ2 = chrom2[t]
             if typ1:
                 lengs=lengs+len(typ1)
                 tcount=tcount+1
                 #Get a cluster
                 for curTup in typ1:
                     clust = clust+1
                     #Compare this cluster with those in the same folder for file2
                     for k in range(0,len(typ2)):
                         tup2 = typ2[k]                
                         results = clustMatch(curTup,tup2)
                         if (results=="TRUE"):
                             totalCount = totalCount+1
                             #If we have a match we have to break, we only want to know the number of clusters in a which match, not a total count of matches.
                             break
    toReturn =[totalCount,clust]
    return(toReturn)                
                
###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#This function checks if every character in a string is identical to those in another string
def checkStrings (s1,s2):
    #If the lengths are different return false
    l1 = len(s1)
    l2 = len(s2)
    if l1!=l2:
        return("FALSE")
    #For each character in s1
    for c in range(len(s1)):
        cha1 = s1[c]
        cha2 = s2[c]
        if cha1!=cha2:
            return("FALSE")
    return("TRUE")
    
    
###This exciting new function takes a matrix and sorts it by the headers which tell the number of  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  
    
###------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Takes in a list of chromosome bins with touples in them.
##Writes to a csv file in the directory
def toExport(lstOfFiles, myDir,tableT):

    #Sort the lists
    myLstSorter = cvcLst()    
    myLstSorter.sort()     
    
    lstOfFileNames = myLstSorter.names
    clustNumsOfFiles = myLstSorter.nClusts
    readNumsOfFiles = myLstSorter.nReads

    #Sort the list of files
    nlstOfFiles = []
    for ind in myLstSorter.indicesLst:

        #Add at the indices to the list
        curF = lstOfFiles[ind]
        nlstOfFiles.append(curF)
        lcount=0
        for cr in curF:
            for cd in cr:
                lcount=lcount+len(cd)

        
    #
    #First create the matrix which will be used to store the final information
    numRuns = len(lstOfFiles)
    toExport = [["" for i in range(numRuns+1)] for j in range(numRuns+1)]
    #Set the names
    lstOfFileNames.insert(0,'')
    toExport[0]=lstOfFileNames
    #Find each value
        #Loop over first values
        
    #Display value
    displayEnd = numRuns*numRuns - numRuns
    displayEnd = displayEnd/2
    print("Counting up to: ",displayEnd)    
    displayCount=0
    for r in range(0,numRuns):
        file1 = nlstOfFiles[r]
        
        
        
        #Fill in the table names
        toExport[r][0]=lstOfFileNames[r]
        #Loop over second values
        for h in range(0,numRuns):                                    
            #Get the second value
            file2 = nlstOfFiles[h]
            
            
            #Set identical ones to blank
            if r==h or h>r:
                if (r!=0 and h!=0):
                    toExport[r][h]=''
            #Aquire the reads of the remaining and populate them
            else:
                onTop=False
                #Now we need to get the newMax value~~~~~~~~~~~~~~~~~~~~~~~~~
                    #Store the two possible cluster options in list
                opti1 = getNumClustsTester(file1)
                opti2 = getNumClustsTester(file2)
                clusterOptions = [opti1,opti2]
                sortedClusterOptions = clusterOptions
                sortedClusterOptions.sort()
                    #Get the larger and smaller
                smaller=sortedClusterOptions[0]
                larger=sortedClusterOptions[1]
                print("Smaller number of clusters",smaller)
                print("Larger number of clusters",larger)
                #Run the match so that the smaller file is first
                if (smaller == clusterOptions[0]):
                    val = findMatchNum(file2,file1)[0]
                    clustHits =findMatchNum(file2,file1)[1]
                elif (smaller== clusterOptions[1]):
                    val = findMatchNum(file2,file1)[0]
                    clustHits =findMatchNum(file2,file1)[1]
                print("Number of matches",val)
                #Now we want to figure out what fraction of this value the original value represents
                val = val/smaller
                val = val*100
                val = round(val, 3)
                print("Clusters parsed: ",clustHits)
                print("Output value",val)
                print("-------------------------------------------------------------------------------------------------------------------")
                    #Now we want to make the top values blank:
                if onTop==True:
                    val = ''
                
                displayCount=displayCount+1
                print(displayCount)
                
                toExport[r+1][h+1] = val
                val=0
                
    toExport[0][0]=tableT
    #Get the final row name
    inde = len(lstOfFileNames)-1
    toExport[inde][0]=lstOfFileNames[inde]
    
    #Add reads row
    ###---------------------------------------------------------
    readNumsOfFiles.insert(0,"Number of reads in catagory clusters")
    toExport.append(readNumsOfFiles)
    ###---------------------------------------------------------
    #Add clusters row
    ###---------------------------------------------------------
    clustNumsOfFiles.insert(0,"Number of clusters in catagories")
    toExport.append(clustNumsOfFiles)
    ###---------------------------------------------------------
    
    print("Completed")
    
        #Export as csv
    csvfile = myDir

    csvfile=myDir+"crosshatch.csv"
    #Assuming res is a flat list
    print("Saving to: ",csvfile)
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        for val in toExport:
            writer.writerow([val])    

    #Assuming res is a list of lists
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        writer.writerows(toExport)
        
###TO BE CIVILIZED I ADDED A RUN FUNCTION
def run(inpDir,tlist,outpt):
    for w in lstOfFileNames:
        print(w)
    #Make the title of the table
    tabTitle = "Catagories used: "
    for ele in tlist:
        tabTitle = tabTitle+ele+", "
    
    lod = makeListofDictionaries(inpDir,tlist)
    cts = convertToBins(lod,tlist)
    fin = toExport(cts,outpt,tabTitle)
    
Mytlist = ["3'utr","5'utr","intron","exon","CDS"]


my_parser = argparse.ArgumentParser(prog='clusterVcluster',description='Find cluster overlap between csv cluster files.')

my_parser.add_argument('cInput',metavar='clusterInput',type=str,help='The input cluster file(s). Either a .csv file or a directory (in this case the analysis will be run on all csv files in that directory).')
my_parser.add_argument('outDir',metavar='outputDirectory',type=str,help='The directory in which all output files will be generated.')
args = my_parser.parse_args()

run(args.cInput,Mytlist,args.outDir)