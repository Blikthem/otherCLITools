PCA Pipeline
Automatically run star mapping, PICARD get metrics, differential expression, and PCA visualization on a directory of fastqs. Nothing special or novel here, I just got tired of doing them manually. Before the PCA is done you have some filtering based on gene expression and inter-group variation. See the pipeline to see what values were hard coded for this step (where you can change them). The main executable is PCA_Pipe.sh. The inputs are:
#Input 1 -> The directory which contains the fastqs to map, quantify, and PCA
#Input 2 -> The STAR index directory  to use for annotation.
#Input 3 -> Output directory
#Input 4 -> The RSEM reference to use for expression quantification, in path/prefix form (ex /home/claypooldj/genomes/RSEM/rsem_hg38)
	#OPTIONAL INPUT
#Input 5 -> Groups. Here is where you say which fastq files are replicates of a biological condition. This is used to remove genes that show high variation within a group. Format as follows:
#	Input 5 format: Each group should be written in [] which contain string of each input file. DO NOT INCLUDE THE FILE EXTENSION (.fastq, .fastq.gz etc) Place each of these group in an outer [] seperated by commas. Ommited input files are assumed to be part of no group.
#	Input 5 example: [["sample_A1","sample_A2"],["sample_B1","sample_B2"]] 
