#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 11:54:42 2020

@author: claypooldj
"""
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Load packages 
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import sys
from dittoClusters_4 import run
#random.seed(5041995)



#INPUT VARIABLES (CL)------------------------------------------------------------------------------------------
#Argument 1 - Longest transcript metagene annotation file
anotF=sys.argv[1]
#Argument 2 - input directory
inpDir=sys.argv[2]
#Argument 3 - directory where the output directory will be generated
outDir=sys.argv[3]
#Argument 4 - Which genic regions to consider. List "Auto" to match to cluster alignment.
genicReg=sys.argv[4]
#Argument 5 - Create a number of ghost clusters for each cluster equal to the read count?
scale=sys.argv[5]

run(anotF,inpDir,outDir,genicReg,scale)