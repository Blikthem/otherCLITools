#Runs zscore comparison and kmer generation between two fasta files.

#REQUIRED INPUTS----------------------------
kMerL=5
clusterFASTA="PTBP1_clustersUsed.fasta"
referenceFASTA="PTBP1_backgroundMimic_wbrc.fasta"
scriptDir="/home/claypooldj/kMerZ_Ditto/scripts"
inputDir="/home/claypooldj/kMerZ_Ditto/testOut1/PTBP1_kMer_Output"
outputDir=/home/claypooldj/kMerZ_Ditto/scripts/testIn
#--------------------------------------------

#Step 5: Generate the set of reference k-mers --------------------------------------------
echo -n "Creating reference k-mers ..."
refOut=$outputDir
refOut+=/kMerReferences.txt
perl $scriptDir/kmer-set-maker.pl $kMerL > $refOut
#-----------------------------------------------------------------------------------------

#Step 6: Counting k-mers --------------------------------------------
echo -n "Counting k-mers ..."
theOut1=$clusterFASTA
theOut1+=_kMerCountsSeq.tsv
theOut2=$referenceFASTA
theOut2+=_kMerCountsBackground.tsv
perl $scriptDir/kmer-counter.pl kMerReferences.txt $clusterFASTA $theOut1
perl $scriptDir/kmer-counter.pl kMerReferences.txt     $referenceFASTA $theOut2

#perl $scriptDir/kmer-counter.pl kMerReferences.txt ${inputsam%.*}_expanded.fa ${inputsam%.*}_kMerCountsSeq.tsv
#perl $scriptDir/kmer-counter.pl kMerReferences.txt	${inputsam%.*}_scrambled.fa ${inputsam%.*}_kMerCountsBackground.tsv
#--------------------------------------------------------------------

#Step 7: Calculate Z scores --------------------------------------------
#echo -n "Calculating Z scores ..."
#python $scriptDir/z-score_calculator_vMe.py ${inputsam%.*}_kMerCountsSeq.tsv ${inputsam%.*}_kMerCountsBackground.tsv kMerZScores.tsv
#--------------------------------------------------------------------
