module laod python/3.7.2
a1=/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged/
a2=/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged/
outDir=/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged/

mkdir $outDir
python /home/claypooldj/rRNADepletion/blat/rRNA_Consolidate_Paired_CLI.py $a1 $a2 $outDir
