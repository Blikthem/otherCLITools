rRNA Detector
Uses the BLAT sequence similarity test to quantify the amount of rRNA found in a each fastq in a directory of fastq files by comparing with a directory of reference rRNA fasta files.

Main pipeline CLI executable: blat_engine_dir.sh

#README - Inputs ---------------------------------------------------
#Directory containing all of the fastqs to search for rRNA, with path (input 1)
#Directory with all of the rRNA reference FASTAS (input 2)
#Blat executable (input 3)
#Output directory (input 4)
#Directory containing the blat_engine_indivFQ.sh executable (input 5)
#Directory containg the star index files (input 6)
#Ref flat file (input 7)
#Path to the picard jar file (input 8)
