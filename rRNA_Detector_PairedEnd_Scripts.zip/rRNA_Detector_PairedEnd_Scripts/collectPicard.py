#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 10:41:29 2020

@author: claypooldj
"""
import os
import pandas as pd

DFs_bothMapped=[]
DFs_oneMapped=[]
DFs_neitherMapped=[]

inputDir="/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged"
outDir="/home/claypooldj/rRNADepletion/2020/blat_pipeline_output_unmerged"

for subdir, dirs, files in os.walk(inputDir):
    withoutPath=os.path.basename(subdir)
    if "_Compiled" in withoutPath:
        print(os.path.basename(subdir))
        for other in ["bothMappedAnalysis","neitherMappedAnalysis","oneMappedAnalysis"]:
            toAdd=inputDir+"/"+withoutPath+"/"+other+"/picard_metrics_only.tsv"
            nDF=pd.read_csv(toAdd,sep="\t")
            nDF.index=[os.path.basename(subdir)]
            if other=="bothMappedAnalysis":
                DFs_bothMapped.append(nDF)
            if other=="neitherMappedAnalysis":
                DFs_neitherMapped.append(nDF)
            if other=="oneMappedAnalysis":
                DFs_oneMapped.append(nDF)

result_bothMapped = pd.concat(DFs_bothMapped, sort=False)
result_oneMapped = pd.concat(DFs_oneMapped, sort=False)
result_neitherMapped = pd.concat(DFs_neitherMapped, sort=False)

result_bothMapped.to_csv(outDir+"/bothMapped_PicardSummary.csv")
result_oneMapped.to_csv(outDir+"/oneMapped_PicardSummary.csv")
result_neitherMapped.to_csv(outDir+"/neitherMapped_PicardSummary.csv")