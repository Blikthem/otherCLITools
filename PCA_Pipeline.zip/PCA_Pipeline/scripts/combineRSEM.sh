#combineRSEM (DJC)
#This program combines all RSEM output files in one directory and outputs the new (combined) gene expression file into a specified output directory.

module load rsem/1.1.21

#Inputs------------------------------------------------------
#Input 1 - Input directory (str)
#Input 2 - Output directory (str)
#------------------------------------------------------

INPUTDIR=${1?Error: no input directory specified. Variable 1.}
OUTDIR=${2?Error: no output directory specified. Variable 2.}

cd $1

#Create a string to populate as the left parameter of the rsem-generate-data-matrix function
toJoin=""

#Populate a combine variable for all of the files in this other data base
for f in *
do
 toJoin+=$f
 toJoin+=" "
done

echo "Combining" $toJoin

#Run the rsem combination and output the results to the output directory
outPut=$2
outPut+="/geneExpression_AllSamples.tsv"
rsem-generate-data-matrix $toJoin >$outPut
