module load star/2.5.2b

#Inputs----------------------------------------------------------------------------
inputDir=$1
genomeDirectory=$2
#----------------------------------------------------------------------------

#Run----------------------------------------------------------------------------
	#Change directories to one of interest
cd $inputDir

#1: Both Mapped --------------------------
	#Create output directory
outDir=$inputDir
outDir+=/bothMappedAnalysis_forPCA
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/bothMapped_STAR_forPCA"

echo "Running alignment on mapped_inBoth FASTQs"
	#Run 
STAR --genomeDir $genomeDirectory --readFilesIn mapped_inBoth_R1.fastq mapped_inBoth_R2.fastq --outFileNamePrefix $starOut --quantMode TranscriptomeSAM --runThreadN 8

#2: One Mapped --------------------------
        #Create output directory
outDir=$inputDir
outDir+=/oneMappedAnalysis_forPCA
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/oneMapped_STAR_forPCA"

echo "Running alignment on mapped_inBoth FASTQs"
        #Run
STAR --genomeDir $genomeDirectory --readFilesIn mapped_inOne_R1.fastq mapped_inOne_R2.fastq --outFileNamePrefix $starOut --quantMode TranscriptomeSAM --runThreadN 8

#3: Neither Mapped --------------------------
        #Create output directory
outDir=$inputDir
outDir+=/neitherMappedAnalysis_forPCA
mkdir $outDir
	#Create output prefix
starOut=$outDir
starOut+="/neitherMapped_STAR_forPCA"

echo "Running alignment on mapped_inBoth FASTQs"
        #Run
STAR --genomeDir $genomeDirectory --readFilesIn mapped_notInBoth_R1.fastq mapped_notInBoth_R2.fastq --outFileNamePrefix $starOut --quantMode TranscriptomeSAM --runThreadN 8

#----------------------------------------------------------------------------
