toCheck="/home/claypooldj/rRNADepletion/fastqs/Detergent_NEB.fastq"
if [ $(head -c4 $toCheck) == '@HWI' ]
then
 echo "Starts with HWI"
else
 echo "It does NOT start with HEW"
fi
