#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 16 14:38:28 2020

@author: claypooldj
"""
#Depencies
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import sys


#Inputs----------------------------------------------------------------------------------------
#inputFile="/Users/claypooldj/Desktop/bothMapped_picard_output.txt"
#outDir="/Users/claypooldj/Desktop"
inputFile=sys.argv[1]
outDir=sys.argv[2]
#----------------------------------------------------------------------------------------

#Run
file1 = open(inputFile, 'r') 
Lines = file1.readlines() 

toDF=[]
start=False
for line in Lines: 
    if start==True:
        if len(line)==1:
            break
        toDF.append(line)
    if '## METRICS CLASS' in line:
        start=True
    
#Save temporary file
toSaveTemp=outDir+"/picard_metrics_only.tsv"
file2=open(toSaveTemp,'w+')
for line in toDF:
    file2.write(line)
file2.close()

#Read the metrics file to pandas data frame
df=pd.read_csv(toSaveTemp,sep='\t')
print(df)

#Pie chart 1 -------------- BASES
baseCats = ['CODING_BASES','UTR_BASES','INTRONIC_BASES','INTERGENIC_BASES']
baseLabels=['CODING','UTR','INTRONIC','INTERGENIC']
sizes = []
for theCat in baseCats:
    theList=list(df[theCat])
    sizes.append(int(theList[0]))
    
y_pos = np.arange(len(baseCats))
plt.bar(y_pos, sizes, align='center', alpha=0.5)
plt.xticks(y_pos, baseLabels)
plt.ylabel('Base count')
plt.title('Base Distribution')

toSave1=outDir+"/baseDistributionPlot.pdf"
plt.savefig(toSave1)