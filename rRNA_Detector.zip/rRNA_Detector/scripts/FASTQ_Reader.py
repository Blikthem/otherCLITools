#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  9 14:26:00 2020

@author: claypooldj
"""

#Inputs------------------------------------------------------------------------------------------------
inpFASTQ1="/Volumes/Untitled/Output/rRNA/consolidate_Paired/"
#-------------------------------------------------------------------------------------------------------

#Classes------------------------------------------------------------------------------------------------
class FASTQread:
    """
    FASTQread Object: This object represents a read from a fastq file.

    Properties:
        ID(String) - The identifier of the sequence.
        sequence(String) - The nucleotide sequence.
        sep(String) - The seperator character.
        QScore(String) - Quality score.
    
    Methods:
        init - Initializer
        str - Conversion to string form for printing

    """
    def __init__(self, ID,sequence,sep,QScore):
        """
        Initalizing method.
        """
        self.ID=ID
        self.sequence=sequence
        self.sep=sep
        self.QScore=QScore

    def __str__(self):
        toPrint="{FASTQread Object}: \n"+self.ID+"\n"+self.sequence+"\n"+self.sep+"\n"+self.QScore
        return(toPrint)
        
    def toWrite(self):
        toPrint=self.ID+"\n"+self.sequence+"\n"+self.sep+"\n"+self.QScore+"\n"
        return(toPrint)
#-------------------------------------------------------------------------------------------------------
        
#Functions----------------------------------------------------------------------------------------------
def getBeforeSpace(inpStr):
    """
    Takes a string and returns a substring over everything before a space.
    Input:
        inpStr (str) - String with a space.
    Returns:
        str - The string before a space.
    """
    toRet=""
    for indC in inpStr:
        if indC!=' ':
            toRet=toRet+indC
        elif indC==' ':
            return(toRet)
    return(toRet)
def readFASTQ(inpFile,outputType):
    """
    Reads a fastq file to a python dictionary (or list) of FASTQread objects.
    Input:
        inpFile (str) - Fastq file to load.
        outputType (str) - What output format? Dictionary or List.
    Output:
        List
            or
        Dictionary
            Key = Sequence ID (str)
            Value = FASTQread
    """
    if outputType=="Dictionary":
        toRet={}
    elif outputType=="List":
        toRet=[]
    print("Loading: "+inpFile+"...")
    #Read in the lines
    file1 = open(inpFile, 'r') 
    lines = file1.readlines() 

    #Object variables
    lineCounter=0
    var_ID=""
    var_seq=""
    var_sep=""
    var_QS=""
    
    for line in lines:    
        theLine=line.strip()
        lineCounter=lineCounter+1
        
        if lineCounter==1:
            var_ID=theLine
        if lineCounter==2:
            var_seq=theLine
        if lineCounter==3:
            var_sep=theLine
        if lineCounter==4:
            var_QS=theLine
            #Create the object
            nRead=FASTQread(getBeforeSpace(var_ID),var_seq,var_sep,var_QS)
            #Add it to the return structure
            if outputType=="List":
                toRet.append(nRead)
            if outputType=="Dictionary":
                toRet[getBeforeSpace(var_ID)]=nRead
            
            #Resest variable values
            lineCounter=0
            var_ID=""
            var_seq=""
            var_sep=""
            var_QS=""
    print("...Loaded.")
    print("Len: ",len(toRet))
    return(toRet)
#-------------------------------------------------------------------------------------------------------
