module load python/3.7.2

python /home/claypooldj/CLI_Tools/clusterOverlap/ClustervCluster_VEchidnaServer_CLI.py /home/claypooldj/myPythonScripts/HMCSVFiles_Tri /home/claypooldj/CLI_Tools/clusterOverlap/exampleOut/
