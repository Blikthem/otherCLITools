This runs the cross-hatch generating program which finds overlap between lists of cluster.csv files. Contrained to PARALYZER output format. Current considers clusters from:
["3'utr","5'utr","intron","exon","CDS"]
annotation categories. If you want to adjust these go to line 684 in the python script.

Inputs:
cInput - Directory with input csv files.
outDir - Directory where the output csv file should be saved.
