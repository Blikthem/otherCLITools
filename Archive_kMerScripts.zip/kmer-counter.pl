#!/usr/bin/perl
$|++;
use warnings;
use strict;
####################### FILES #######################
my $input_kmers = shift;
my $input_fa = shift;
my $output_kmers_counts = shift;
if (!defined($output_kmers_counts))
{die "USAGE: perl $0 need file-inputs and file-output";}
#################### VARIABLES ######################

my $line;
my $kmer_length;
my $count;
my $final_position;
my $full_nucleotide_string;
my $current_nucleotide_string;
my %kmer; 


# get KMERs from kmer newline delimited file
open KIN, $input_kmers or die "could not open kmer_input";
$line = <KIN>;
chomp $line;
$kmer_length=length($line);
#print "length of kmer = $kmer_length \n";
while ($line = <KIN>)
{
	# chomp and split line,
	chomp $line;
	$kmer{$line}=0;
}
close KIN;


# read in input fasta, counts kmers
open FIN, $input_fa or die "could not open fasta_input";
while ($line = <FIN>)
{
	if ($line !~ /^>/)
	{
		chomp $line;
		$full_nucleotide_string=uc $line;
		$final_position=length($full_nucleotide_string)-$kmer_length;
		
		foreach my $i (0..$final_position)
		{
			$current_nucleotide_string=substr($full_nucleotide_string,$i,$kmer_length);
			$kmer{$current_nucleotide_string}++;
		}
		
	}

}
close FIN;


#output counts
open KCO, ">$output_kmers_counts" or die "could not open file_kmer_output";
foreach my $k (keys %kmer)
{
	$count=$kmer{$k};
	print KCO "$k\t$count\n";
}
close KCO;

