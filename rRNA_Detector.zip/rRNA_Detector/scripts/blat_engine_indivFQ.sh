#!/bin/sh
module load python/3.7.2

#README - Inputs ---------------------------------------------------
#Fastq to search for rRNA, with path (input 1)
#Directory with all of the rRNA reference FASTAS (input 2)
#Blat executable (input 3)
#Output directory (input 4)
#----------------------------------------------------------------------------------------

#Run statements ---------------------------------------------------
echo "Input Summary------------------------------------------------------"
echo "Searching: $1"
echo "against the references in: $2"
echo "using this blat executable: $3"
echo "and creating output directory in: $4"
echo "------------------------------------------------------"
#---------------------------------------------------
#Fastq name (without extension or file path)
fqname=$(basename "$1" .fastq)

#Create the output directory
outDir=$4
outDir+="/"
outDir+=$fqname
outDir+="_rRNA_Mapped"
mkdir $outDir

#Generate the file of all the headers and adjust to match Illumina format
#NOTE - This step is specific to the HiSeq Illumina sequencing machine's format so other labs will have to adjust according to the annotation strategy of their machines.
cd $outDir

if [ $(head -c4 $1) == '@HWI' ]
then
 echo "Starts with HWI"
 LC_ALL=C fgrep '@HWI' $1 >all_headers.txt
else
 LC_ALL=C fgrep '@' $1 >all_headers.txt
fi


#HERE IS WHAT THE LINE USED TO SAY:
#LC_ALL=C fgrep '@HWI' $1 >all_headers.txt
#NOW ITS SAYS
#LC_ALL=C fgrep '@' $1 >all_headers.txt

sed 's/.\{13\}$//' all_headers.txt >all_headers_reformatted.txt
sed -i "s/^.//g" all_headers_reformatted.txt
totalSequences=$(wc -l all_headers_reformatted.txt | awk '{print $1}')
echo "Total Number of Sequences: $totalSequences"

#Generate fasta version of the inputed fastq
inputFasta=$outDir
inputFasta+="/"
inputFasta+=$fqname
inputFasta+=".fa"
paste - - - - < $1 | cut -f 1,2 | sed 's/^@/>/' | tr "\t" "\n" > $inputFasta
echo "FASTA version of the input FASTQ has been created"

#Get the largest file in the reference dir
largestRef=$(find $2 -type f | xargs ls -1S | head -n 1)
echo "Largest reference file: $largestRef"

#Start to write the output file
outSummary=$fqname
outSummary+="_rRNA_Mapping_Summary.tsv"
printf "BLAT BASED rRNA MAPPING SUMMARY \n" >>$outSummary
printf "FASTQ \t $fqname \n" >>$outSummary
printf "Total Number of Sequences \t $totalSequences \n" >>$outSummary
printf "Anotation FASTA Name \t Number of Mapped Sequences \t Percent of Total \n" >>$outSummary

#For each fasta genome reference file
for refFasta in $2/*
do
 echo "BLAT Run ------------------------------------------------------"
 #Fasta name (no extension)
 filename=$(basename "$refFasta")
 ext="${filename##*.}"
 refName=$(basename "$refFasta" $ext)

 #Run the blast
 echo "FASTA annotation being used: $refFasta"
 #Get the name of the blat output file
 bOut=$outDir
 bOut+="/"
 bOut+="Blat_"
 bOut+=$fqname
 bOut+="_against_"
 bOut+="$refName"
 bOut+="pslx"
 $3 -t=dna -q=dna -out=pslx -noHead $refFasta $inputFasta $bOut
 
 # Collect unique mapped reads using cut command with sort unique corollary:
 cut -f 10 $bOut | sort -u >mapped_headers_temporary.txt
 curHits=$(wc -l mapped_headers_temporary.txt | awk '{print $1}')
 printf "$refName \t $curHits \t $((100 * curHits / totalSequences)) \n" >>$outSummary
 rm mapped_headers_temporary.txt

 echo "Total number of hits: $curHits"
 echo "------------------------------------------------------"

 #If this is the largest reference file, then we need to use it to generate rRNA mapped and rRNA unmapped files
 if [ $largestRef == $refFasta ]
 then
  echo "Generating the mapped/unmapped fastq files from the BLAT against the largest anotation file ($refFasta)"
  #1) Collect unique mapped reads using cut command with sort unique corollary:
  cut -f 10 $bOut | sort -u >mapped_headers.txt

  #2) Collect the headers which are unmapped
  awk 'NR==FNR{a[$0];next}!($0 in a)' mapped_headers.txt all_headers_reformatted.txt >unmapped_headers.txt

  #3)Grep those reads from the original fastq file.
  LC_ALL=C grep -A 3 -F -f unmapped_headers.txt $1 >temporary_unmapped.fastq
  LC_ALL=C grep -A 3 -F -f mapped_headers.txt $1 >temporary_mapped.fastq

  #Fix the fastq files to remove the --'s introduced via fgrep -A
  echo "Adjusting the fastq file to remove the --'s indtroduced via fgrep"
  python /home/claypooldj/rRNA_Detector/scripts/fixFastq.py temporary_mapped.fastq mapped.fastq
  python /home/claypooldj/rRNA_Detector/scripts/fixFastq.py temporary_unmapped.fastq unmapped.fastq     
 fi


done

echo "Complete."
