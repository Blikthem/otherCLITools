#Import lines
import csv
import numpy as np
import os
import matplotlib.pyplot as plt  

import sys
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Define objects and their various methods
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
class cluster:
    """
    Cluster Object: This object represents a cluster identified by PARALYZER - a row from a clusters.csv output file.

    Properties:
        Pulled from csv rows as strings - chrom (chromosome), strand (strand oriented to), start (starting index in cluster), end (ending index of cluster), gene (gene that paralyzer aligned this cluster to if any), CS (conversion specificity), T2C (T to C fraction), URC (Unique read count for this cluster), RC (total read count)
    
    Methods:
        init - Initializer
        str - Conversion to string form for printing
    """
    def __init__(self,seq,chrom,strand,start,end,gene,CS,T2C,URC,RC):
        self.seq=seq
        self.chrom=chrom
        self.strand=strand
        self.start=start
        self.end=end
        self.gene=gene
        self.CS=CS
        self.T2C=CS
        self.URC=URC
        self.RC=RC
        
    def __str__(self):
            toPrint="{Cluster Object} Gene: "+self.gene+"\tStart: "+str(self.start)+"\tEnd: "+str(self.end)+"\tChromosome: "+str(self.chrom)
            return(toPrint)
            
class groupOfKmers:
    """
    Cluster Object: A group of kMers sorted by hierarchical clustering.

    Properties:
        groupedKMers(List[kMer]) - The kMers that are clustered into this group.
        coverage(float) - The total coverage of clusters to this hierarchical group of kMers.
    
    Methods:
        init - Initializer
        str - Conversion to string form for printing
    """
    def __init__(self,gkm):
        self.groupedKMers=gkm
        self.coverage=0
        self.percentClustersContaining=0
        self.percentOfClusterReadSpace=0
        
    def __str__(self):
            toPrint="{Group of kMers Object} Number of kMers: "+str(len(self.groupedKMers))
            return(toPrint)
            
    def getCoverage(self,clustList):
        """
        Determines what percent of clusters in a given list of clusters contain a kMer from this list. Also expresses in terms of read space.
        Input:
            clustList (List[cluster]) - List of clusters to look in.
        Output:
            float - Percent of clusters in the list which contain the kMer
        """
        containing=0
        #For each cluster
        for clust in clustList:
            #For each kmer
            for inst in self.groupedKMers:
                if inst.withinCluster(clust)==True:
                    containing=containing+1
                
        if containing==0:
            return(0)
            
        self.percentClustersContaining=100*containing/len(clustList)
        
        return(100*containing/len(clustList))
            
class kMer:
    """
    Class representing a single kMer.
        Sequence(String) - The sequence of characters making up the kmer
        zScore(Float) - The z-score of this kMer relative to the background
        observedFreq(Float) - Log10 of the count of this kmer within the observed (not background) sequence
        percentClustersContaining(Float) - The percent of clusters which contain this kmer.
        percentOfClusterReadSpace(Float) - The percent of the cluster read space taken up by clusters containing the kMer.
    """
    def __init__(self,sequence,zScore,observedFreq):
        self.sequence=sequence
        self.zScore=float(zScore)
        self.observedFreq=float(observedFreq)
        self.K=len(sequence)
        self.percentClustersContaining=0
        self.percentOfClusterReadSpace=0
    
    def __str__(self):
        """
        Returns a string that represents the object
        """
        toRet="{kMer Object} Sequence: "+self.sequence+" zScore: "+str(self.zScore)+" freq: "+str(self.observedFreq)
        return(toRet)
        
        
    def withinCluster(self,clust):
        """
        Determines whether a kMer is within a given cluster object.
        Input:
            clust (Cluster) - Cluster to look for the KMer in.
        Output:
            bool
        """
        return(self.sequence in clust.seq)

    def whatPercentContain(self,clustList,totalRC):
        """
        Determines what percent of clusters in a given list of clusters contain this kMer. Also determines the percent of read space for the cluster.
        Input:
            clustList (List[cluster]) - List of clusters to look in.
            totalRC (Int) - The total number of reads aligned to clusters.
        Output:
            float - Percent of clusters in the list which contain the kMer
        """
        containing=0
        containingReads=0
        for clust in clustList:
            if self.withinCluster(clust)==True:
                if is_int(clust.RC)==True:
                    containing=containing+1
                    containingReads=containingReads+int(clust.RC)
                else:
                    containing=containing+1
                    containingReads=containingReads+1
                
        if containing==0:
            return(0)
        
        toCheckLS=["GTTTAA"]
        toCheckUS=["GATTAT"]
        if self.sequence in toCheckLS or self.sequence in toCheckUS:
            print("kMer------------------ ",self.sequence)
            print("Containing reads: ",containingReads)
            print("TotalRC: ",totalRC)
        self.percentClustersContaining=100.0*containing/len(clustList)
        self.percentOfClusterReadSpace=100.0*containingReads/totalRC
        #Calculate 
        
        return(100.0*containing/len(clustList))

    def getAsNpArray(self):
        """
        Converts the kMer into a single numpy array using the following mapping
            A = 0
            C = 1
            T = 2
            G = 3
            N = 4
        Returns:
            numpy Array
            """
        temp=[]
        for ch in self.sequence:
            if ch=='A':
                temp.append(0)
            if ch=='C':
                temp.append(1)
            if ch=='T':
                temp.append(2)
            if ch=='G':
                temp.append(3)
            if ch=='N':
                temp.append(4)
        
        toRet = np.asarray(temp)
        return(toRet)

    def generateListOfSub(self,n):
        """
        Generates a list of all sub-kMer sequences of length n for this kMer. These are only the kmers which are shifted from the side (othewise it is not actually a shift but a submer)
        Input:
            n(int) - minimum length of shift to consider.
        Output:
            List[String] - List of contained submers
            """
        toRet=[]
        #Findal the bins on eiethr side to be checked
        endInd=len(self.sequence)-n
        #For each of the end indices on the left....
        for i in range(endInd+1,len(self.sequence)):
            subSeq=self.sequence[0:i]
            for val in range(0,len(self.sequence)-i):
                subSeq=subSeq+'X'
            toRet.append(subSeq)
        
        #...For each of the end indices on the right
        for i in range(endInd+1,len(self.sequence)):
            subSeq=''
            for val in range(0,len(self.sequence)-i):
                subSeq=subSeq+'X'
            subSeq=subSeq + self.sequence[len(self.sequence)-i:len(self.sequence)]
            toRet.append(subSeq)        
        
        return(toRet)
        

class kMerZFile:
    """
    Class representing a tsv file that contained kMer information and 
    """
    def __init__(self,fileName):
        self.fileName=fileName
        self.lstOfkMers=[]
        self.lstOfGroupedkMers=[]
    
    def __str__(self):
        """
        Returns a string that represents the object
        """
        toRet="{kMerZFile Object} FileName: "+self.fileName+" number of kMers: "+str(len(self.lstOfkMers))
        return(toRet)
    
    def addkMer(self,kMer):
        """
        Adds kmer to the object
        Input:
            kMer - Object to add
        """
        self.lstOfkMers.append(kMer)
        
    def sortByZ(self):
        """
        Sort the contained kMer objects by descending Z value.
        """
        self.lstOfkMers = sorted(self.lstOfkMers,key=lambda x:x.zScore,reverse=True)
        
    def getFirstN(self,N):
        """
        Returns a list containing the first N number of kMers from the contained list:
        Input:
            N (Int) - Number of kMers to pull.
        Output:
            List[kMer]
        """
        newL=self.lstOfkMers[0:N]
        return(newL)
    
    def getFirstPercent(self,percent):
        """
        Returns a list containing the top N number of kMers from the contained list:
        Input:
            percent (Int) - Number of kMers to pull.
        Output:
            List[kMer]
        """
        #Get the length to take
        finLen=int(len(self.lstOfkMers)*percent/100)
        newL=self.lstOfkMers[0:finLen]
        return(newL)


    def getNucleotideComp(self,position,numberkMers):
        """
        Return the breakdown of nucleotides in the X position in the top Y number of kMers
        Input:
            position (Int) - Index of the kMer position to consider.
            numberkMers (Int) - Number of kMers in the list of kMers to consider.
        Output:
            List[Float]
        """
        if numberkMers>len(self.lstOfkMers):
            print("Error: You chose an index greater than the number of kMers in the object. Terminating.")
            return()
        #Master list
        ml=[]
        for i in range(0,numberkMers):
            kmr=self.lstOfkMers[i]
            seq = kmr.sequence
            #Nucleotide
            nt = seq[position]
            ml.append(nt)
        
        #Count the numbers of each
        aCount=0
        cCount=0
        gCount=0
        tCount=0
        
        for nt in ml:
            if nt=='A':
                aCount=aCount+1
            if nt=='C':
                cCount=cCount+1                
            if nt=='G':
                gCount=gCount+1        
            if nt=='T':
                tCount=tCount+1
                
        toRet=[aCount/numberkMers*100,cCount/numberkMers*100,gCount/numberkMers*100,tCount/numberkMers*100]
        return(toRet)


    def getNucleotideDist(self,numberkMers,outputDir):
        """
        Return the breakdown of nucleotides in a matrix form for the top x values
        Input:
            numberkMers (Int) - Number of kMers in the list of kMers to consider.
            outputDir (String) - Directory to save the csv matrix of breakdown within.
        Output:
            List[]
        """
        #Get the distribution lists for each position
        aList=['A']
        cList=['C']
        gList=['G']
        tList=['T']
        header=["Position"]
        #For each position
        for p in range(0,len(self.lstOfkMers[0].sequence)):
            #Get the distribution list
            distL=self.getNucleotideComp(p,numberkMers)
            #Add the values to their respective lists
            aList.append(distL[0])
            cList.append(distL[1])
            gList.append(distL[2])
            tList.append(distL[3])
            header.append(p)
            
        mstr=[header,aList,cList,gList,tList]
                
        #Get the name to export to
        csvfile=outputDir+"nucDistribution.csv"
        #Assuming res is a list of lists
        with open(csvfile, "w") as output:
            writer = csv.writer(output, lineterminator='\n')
            writer.writerows(mstr)  
            
        return(mstr)
    
    
    def getKmerPercentagesAll(self,inpDir,clustFile,outputDir,inpTSV,clustDir,fastaDictionary):
        clustL=getParclipClusterList(clustDir,clustFile)
        #Get the total number of reads aligned to cluster
        totalReads=0
        for indClust in clustL:
            if is_int(indClust.RC)==True:
                totalReads=totalReads+int(indClust.RC)
            else:
                totalReads=totalReads+1
        toRet=[]      
        #Output a new tsv with the new information
        header = ["kMer","z-Score","log10(frequency)", "% Clusters with kMer","% cluster read space","% reference clusters"]
        toRet.append(header)     

        for km in self.lstOfkMers:
            #Replace all T's with Us
            nSeq=(km.sequence).replace('T', 'U', 5)
            km.whatPercentContain(clustL,totalReads)
            toAdd=[nSeq,km.zScore,km.observedFreq,km.percentClustersContaining,km.percentOfClusterReadSpace,fastaDictionary.get(km.sequence)]
            toRet.append(toAdd)
            
        #Get the name to export to
        stN = inpTSV[0:len(inpTSV)-4]
        print(stN)
        stN=stN.replace("_kMerZScores_","_")    
        print(stN)
        print("outputDir: ",outputDir)
        csvfile=outputDir+"/"+stN+"_kMers.csv"  
        print("Outputting to: ",csvfile)
        
        #Assuming res is a list of lists
        with open(csvfile, "w") as output:
            writer = csv.writer(output, lineterminator='\n')
            writer.writerows(toRet)  
        
        return(toRet)

    def getAsNpArray(self,N):
        """
        Converts the top N kMers into a single numpy array using the following mapping
            A = 0
            C = 1
            T = 2
            G = 3
            N = 4
        Input:
            N(Int) - Number of kMers to use.
        Returns:
            numpy Array
        """
        #Get the initial array
        fk = self.lstOfkMers[0]
        toRet=fk.getAsNpArray()
        for i in range(1,N):
            km = self.lstOfkMers[i]
            ro = km.getAsNpArray()
            toRet = np.vstack([toRet, ro])
        return(toRet)
        

    def getDistanceMatrix(self,N,Type):
        """
        Creates a distance matrix using the method inputed, for the top N kmers in this object.
        Input:
            N(Int) - Number of kMers to use.
            Type(String) - What kind of distance formula should be used.
                    MatchDistance - Check each position to see if the nucleotides match. If yes, add subtract 1 from distance (max=K)
        Returns:
            numpy Array 
        """
        #Create the empty numpy array to populate with distance values 
        distMatrix=np.empty([N, N])
        #For each kMer of the top N
        for i in range(0,N):
            kMer1=self.lstOfkMers[i]
            #For each in top N:
            for j in range(0,N):
                kMer2=self.lstOfkMers[j]
                #Get the distance value
                if Type=="MatchDistance":
                    dist=kmerMatchDistance(kMer1.getAsNpArray(),kMer2.getAsNpArray())
                else:
                    print("Error: Select appropriate distance function.")
                    return
                #Set the appropriate value in the matrix
                distMatrix[i,j]=dist
        return(distMatrix)

        
    def narrowOutput(self,removeDuplicates,shiftMergInt,removeNonSig):
        """
        Narrows the output file for the kMerZ file to yield greater clarity in mass visualiziation
        Input:
            RemoveDuplicates (bool) - remove duplicate sequences?
            shiftMergInt (int) - Merge those that represent the same kmer shifted up to the inputed shift merge value.
            RemoveNonSig (bool) - Remove the non-significant kmers?
        """
        #Remove duplicates
        if removeDuplicates==True:
            toRem=[]
            counter=0
            for kMer1 in self.lstOfkMers:
                for kMer2 in self.lstOfKmers:
                    if kMer1!=kMer2:
                        #Remove duplicates
                        if kMer1.sequence==kMer2.sequence:
                            toRem.append(counter)
            counter=counter+1
            
            print("Removing duplicates: ",len(toRem))
            for ind in toRem:
                self.lstOfkMers.remove[ind]
        

##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Functions
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
def is_int(val):
    try:
        num = int(val)
    except ValueError:
        return False
    return True
def readInTsv(inpDir,myFile):
    """
    Creates a kMerZFile object from a tsv input file (kMerZ.tsv)
    Input:
        inpDir(String) - The directory with the tsv file
        myFile(String) - The name of the tsv file to be read
    Returns:
        kMerZFile
    """
    #Empty kMerZFile object
    kFile= kMerZFile(myFile)
    #File path direct
    fbd = inpDir+"/"+myFile
    #Open tsv file
    with open(fbd) as tsvfile:
        reader = csv.reader(tsvfile, delimiter='\t')
        for row in reader:
            newKmer=kMer(row[0],row[1],row[2])
            kFile.addkMer(newKmer)
    return(kFile)


def getCSV (myDir,myFile):
    """
    Takes in a directory and file name and creates a list of dictionaries, each reprenting a row. Dictionary values correspond to columns and list enteries correspond to rows
    Input:
        myDir(String) - File path to the directory containing the csv file to be read.
        myFile(String) - Name of the csv file.
    Returns:
        List[Dictionary] - A list of dictionaries, each which represents a row from the csv to read.
    """   
    #Changing the working directory
    wd = myDir
    os.chdir(wd)

    #Upload CSV using the CSV package and an instantiated CSV object
    readCSV = csv.DictReader(open(myFile))
    #Create the master list to be populated
    master_list = []

    
    #poulate this list by grabbing ordered dictionaries
    for line in readCSV:
        master_list.append(line)

    return(master_list)
    
    
def getParclipClusterList(myDir,filename):
    """
    Creates a list of parclip clusters given a file
    Input:
        myDir(String) - File path to the directory containing all of the cluster.csv files to be inputs for the program.
        filename(String) - Name of the cluster file to be used.
    Returns:
        List[Cluster] - A list of clusters from the parclip.
    """ 
    toRet=[]
    currentList = getCSV(myDir,filename)
    #Create the corresponding cluster object
    for cDict in currentList:
        nClust = cluster(cDict.get("ClusterSequence"),cDict.get("Chr"),cDict.get("Strand"),cDict.get("Start"),cDict.get("End"),cDict.get("GeneName"),cDict.get("ConversionSpecificity"),cDict.get("T2Cfraction"),cDict.get("UniqueReads"),cDict.get("ReadCount"))            
        toRet.append(nClust)
        
    return(toRet)
    
def kmerMatchDistance(kmnp1,kmnp2):
    """
    Determines the distance between two kMer sequences of the same length which are stored as numpyarrays.
    Input:
        kmnp1(numpy array) - Array of kMer 1.
        kmnp2(numpy array) - Array of kMer 2.
        
    Returns:
        Int - Distance between the two sequences.
    """ 
    dist = 0
    #Loop over each character in the sequences
    for i in range(0,len(kmnp1)):
        #If the indices are the same
        if kmnp1[i]==kmnp2[i]:
            dist=dist+1
    
    return(len(kmnp1)-dist)

def getIndexOfLargest(vals):
    """
    Determines the largest value in a list and returns its index
    Input:
        List[Num] - List of numbers to check
        
    Returns:
        Int - Index of largest value
    """
    curLargestVal=-1000
    curLargestIndex=0
    for i in range(0,len(vals)):
        curVal=vals[i]
        if curVal>curLargestVal:
            curLargestVal=curVal
            curLargestIndex=i
    return(curLargestIndex)

def checkStringShift(string1,string2,shiftValue):
    '''
    Checks if part of a string (string 2) is a shifted piece of another string (string2).
    Input:
        string1 (Str) - String to check shift against.
        string2 (Str) - String to take substring of and shift.
        shiftValue (int) - The degree the second string should be shifted.
    Return:
        boolean
    '''
    #Loop over string 1 and check it against string2 i+1
    for i in range(0,len(string1)-shiftValue):
        if i!=len(string1)-shiftValue:
            #Get the value for string 1
            val1= string1[i]
            #IF WE AREN'T AT THE END OF THE STRING
            val2=string2[i+shiftValue]
            if val2!=val1:
                return(False)
    return(True)
        

def areStringsShifts(string1,string2,shiftValue):
    '''
    Checks if two strings are shifts of each other - bidirectional.
    Input:
        string1 (Str) - String to check shift against.
        string2 (Str) - String to take substring of and shift.
        shiftValue (int) - The degree the second string should be shifted.
    Return:
        boolean
    '''
    checkF= checkStringShift(string1,string2,shiftValue)
    checkR = checkStringShift(string2,string1,shiftValue)
    if checkF or checkR ==True:
        return(True)
    return(False)


def areStringsShiftsSmallestSeq(string1,string2,smallestSeq):
    """
    Checks if two strings are shifts of eachother using all shift values that will results in a minimum number of overlap (nucleotides)
    Input:
        string1 (Str) - String to check shift against.
        string2 (Str) - String to take substring of and shift.
        smallestSeq (int) - The smallest substring that can be used that will be considered an overlap.
    Return:
        boolean
    """
    #What number of indices shifts will yield that smallest seq of shift?
    nShifts = len(string1)-smallestSeq
    #For each of these check for a shift
    for val in (1,nShifts):
        #Check for overlap
        check = areStringsShifts(string1,string2,val)
        if check==True:
            return(True)
    return(False)
    
def subKmerMatch(km1,km2,minLength):
    """
    Takes two kmers and determines if they have identical sub-kMers (suggesting an identical kMer shift) of at least the threshold length.
    Input:
        km1(kMer) - The first kMer
        km2 (kMer) - The second kMer
        minLength (Int) - The minimum sequence overlap to consider a shifted motif.
    Returns:
        bool - Do they have a sub-kmer in common?
    """
    return(areStringsShiftsSmallestSeq(km1.sequence,km2.sequence,minLength))    

def getkDict_fromFASTA(inpFASTA,kMerTSV):
    """
    inpFASTA (Str) - FASTA file.
    kMerTSV (kMerTSV) - The kMer TSV File.
    """
    toRet={}
    #Loop over the kmers....
    for indK in kMerTSV.lstOfkMers:
        indKmer=indK.sequence
        #Loop over each sequence
        kCount=0
        totalCount=0
        with open(inpFASTA, "r") as a_file:
            for line in a_file:
                stripped_line = line.strip()
                if ">" not in stripped_line:
                    totalCount=totalCount+1
                    if indKmer in stripped_line:
                        kCount=kCount+1
        #Add the percent
        thePerc=float(kCount)/float(totalCount)*100
        toRet[indKmer]=thePerc
    print(toRet)
    return(toRet)

##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
##Running
##------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
def run(inpDir,inpTSV,inpClustCSV,outDir,clusterDir,fastaFile):  
    #Get kmer
    kMerFile = readInTsv(inpDir,inpTSV)
    #Sort
    fastaDict = getkDict_fromFASTA(fastaFile,kMerFile)

    kMerFile.sortByZ()
    #Create spreadsheet including percentage values
    kMerFile.getKmerPercentagesAll(inpDir,inpClustCSV,outDir,inpTSV,clusterDir,fastaDict)

#-------------------------------------------
"""
inpD = "/Volumes/Untitled/Output/kMerBackground/testDitto_2"
inpTab = "PTBP1_kMerZScores_AllClusters_v_backgroundMimic.tsv"
inpClust="PTBP1.csv"
outD = "/Volumes/Untitled/Output/kMerBackground/testDitto_2/"
fastaFile="/Volumes/Untitled/Output/kMerBackground/testDitto_2/PTBP1_backgroundMimic.fasta"
run(inpD,inpTab,inpClust,outD,inpD,fastaFile)
"""