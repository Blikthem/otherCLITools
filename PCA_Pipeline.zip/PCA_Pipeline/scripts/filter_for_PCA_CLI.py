#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 11:38:57 2019
This program is designed to take RSEM output and filter it so that the gene expression sprea
@author: claypooldj
"""
import matplotlib
matplotlib.use('Agg')
#Load dependencies
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys
import os


#INPUT VARIABLES (CL)------------------------------------------------------------------------------------------
#Argument 1 - input directory
myInput=sys.argv[1]
#Argument 2 - directory where the output directory will be generated
outDir=sys.argv[2]
#Argument 3 - Groups
groups=sys.argv[3]
#With defaults
#Threshold
thresh=sys.argv[4]
#Fold ceiling for intra group comparisons
intraFoldCeiling=sys.argv[5]
#Percent to keep of top varience
percentToKeep=sys.argv[6]

#Global list that stores all of the values in the data frame as a simple list
allStartingValues=[]

def stringTList(strGroup):
    """
    This function takes a list of the form [[],[]] which is saved as a string and returns it to its list form
    Input:
        strGroup (str)
    Returns:
        List[List[str]]
    """
    toRet=[]
    if len<=2:
        return(toRet)
    #Loop over all but the first and last values
    toAdd=""
    for i in range(1,len(strGroup)-1):
        #Get the value
        val=strGroup[i]
        if val==']':
            toRet.append(toAdd)
            toAdd=""
        else:
            if val!='[':
                toAdd=toAdd+val

    #Now do the same for the indiviual lists
    toRet2=[]
    for indivStr in toRet:
        #indivStr=indivStr.replace(",","")
        #indivStr=indivStr.replace(" ","")
        print("IndivStr: ",indivStr)
        nList=[]
        start=False
        toAdd=""
        for val in indivStr:
            if start==True and val!="'":
                toAdd=toAdd+val
            if val=="'":
                if start==False:
                    start=True
                else:
                    nList.append(toAdd)
                    toAdd=""
        tmp=[]
        for val in nList:
            if len(val)!=0:
                tmp.append(val)
        toRet2.append(tmp)
    return(toRet2)


def stringTList2(strGroup):
    toRet=[]
    if len(strGroup)<=2:
        return(toRet)
    if ',' not in strGroup:
        return(toRet)
    nGroup=[]
    toAdd=""
    for i in range(1,len(strGroup)-1):
        val=strGroup[i]
        if val not in ("[","]",","):
            toAdd=toAdd+val
        if val=="," and strGroup[i-1]!="]":
            nGroup.append(toAdd)
            toAdd=""
        if val=="]":
            nGroup.append(toAdd)
            toAdd=""
            toRet.append(nGroup)
            nGroup=[]
    return(toRet)
    
toTST='[[rsem_test_.genes.results,rsem_test_2.genes.results,rsem_test_5.genes.results],[rsem_test_3.genes.results,rsem_test_4.genes.results]]' 

def seriesOverThresh(pdSeries, threshold):
    """
    Takes a pandas series in and determines if any of its values is equal to or greater than a specified threshold value.
    Input:
        pdSeries(Pandas series) - Pandas series to scan to check against the threshold.
        threshold (Num) - Minimal value checking against.
    Output:
        bool
    """
    #Get the pd series as a list
    theVals=list(pdSeries)
    theVals.pop(0)
    
    #Loop over each value in the list searching for >=4
    for val in theVals:
        allStartingValues.append(val)
        if val>=float(threshold):
            return(True)
    return(False)

def removeUnderThreshold(pdDF,threshold):
    """
    Input:
        pdDF (Pandas DF) - Data frame to remove rows from.
        theshold (num) - The minimum value one entry in each row must have to be kept
    Returns:
        Pandas DF - New dataframe without any rows that are all under the threshold.
    """
    rowIDToRem=[]
    for index, row in pdDF.iterrows():
        if(seriesOverThresh(row,threshold)==True):
            rowIDToRem.append(row)

    newDF = pd.DataFrame(rowIDToRem)
    return(newDF)

def doesSeriesFCExceedCeil(pdSer,ceil):
    """
    This function determines if the fold between the minimum and maximum value in a series exceeds the ceiling.
    Input:
        pdSer (Pandas series) - PD series ot check.
        Ceil (int) - Fold change ceiling. Any fold change greater or equal to this values yields a True.
    Returns:
        bool
    """
    #Get the min val
    minVal=pdSer.min()
    if minVal==0:
        return(True)
    maxVal=pdSer.max()
    
    theFC=maxVal/minVal
    
    if theFC>=ceil:
        return(True)
    
    return(False)

def removeIntraGroupVariation(pdDF,groups,foldCeil,outDir):
    """
    Takes a gene expression pandas dataframe and removes those rows which have high variation within a group.
    Input:
        pdDF (Pandas data frame) - Master list of gene expression by sample.
        groups (List[List[Str]]) - A list of string lists. Each sublist represents a group.
        foldCeil (num) - The ceiling for fold change. Any fold change equal to or greater than this value within a group will result in the removal of that row.
    Returns:
        Pandas data frame - A new pandas dataframe without the rows with high variation within groups.
    """    
    intermediateDir=outDir+"/filteringFiles"
    #First, end if the group is null
    if groups==[]:
        print("No groups specified. Intragroup variation not considered.")
        return(pdDF)
        
    #The list of genes to remove from the master list
    rowsToRem=[]
    #Indices to rem
    indToRem=[]
    #Save values for bar plot
    #X values (heights of bar plot)
    domain=[]
    #Add the starting value
    domain.append(len(pdDF.index))
    #Y values
    labels=[]
    labels.append("Start")
    #For each group create a new data frame
    i=0
    for indivGroup in groups:
        print("indiv group: ",indivGroup)
        i=i+1
        count=0
        labels.append("Group "+str(i))
        #Create a new data frame
        groupDF = pdDF[indivGroup].copy()
        #Loop over the rows 
        for index, row in groupDF.iterrows():
            #Decide if it needs to be removed
            if (doesSeriesFCExceedCeil(row,foldCeil)==True):
                count=count+1
                rowsToRem.append(row)
                if index not in indToRem:
                    indToRem.append(index)
        domain.append(count)
        
            #Create 
    newDF = pdDF.drop(indToRem)
    
        #Create bar chart to visualize those lost in removing intra group genes above the ceiling
    labels.append("After filtering")
    domain.append(len(newDF.index))
    
    xVals=[]
    for val in range(0,len(groups)+2):
        xVals.append(val)

    x = np.arange(len(labels)) 
    
    fig3 = plt.figure()
    ax3 = plt.subplot(111)
    ax3.bar(xVals,domain)
    ax3.set_xticks(x)
    ax3.set_xticklabels(labels)
    fig3.suptitle("Removal of high intra-group variable genes")
    fig3.savefig(intermediateDir+'/genesRemovedIntraGroup.pdf')
    
    #Create a data frame for rows removed
    removedDF = pd.DataFrame(rowsToRem)

    return(newDF)

def selectHighestVariationGenes(pdDF,groups,percentToKeep,outDir):
    """
    This function takes a data frame and group information and creates a new data frame that only contains the top X genes, by variation between groups.
    """
    intermediateDir=outDir+"/filteringFiles"
    #Create the empty data frame to return - it contains the mean of each group (or a column from a group of one)
    toRetDF = pd.DataFrame()
    #Create a list of all of those columns NOT in a group (they are in their own group)
    allInGroups=[]
    for indivG in groups:
        for val in indivG:
            allInGroups.append(val)
    print("All: ",allInGroups)
        
    #Single columns to add to the calculation matrix (they are all their own groups)
    singles=[]
    for col in pdDF.columns:
        if col not in allInGroups:
            singles.append(col)

    #Add all of the columns NOT in a group directly into the toreturn matrix
    for col in singles:
        toRetDF[col]=pdDF[col]
      
    #For each group create a new data frame
    nameC=0
    for indivGroup in groups:
        colName="Group "+str(nameC)+" mean"
        #Create a new data frame
        groupDF = pdDF[indivGroup].copy()
       # groupDF.to_csv(outDir+colName+".csv")
        #Get the mean and add it as a new column in the singles dataframe
        toRetDF[colName]=groupDF.mean(axis=1)
        nameC=nameC+1
    
    #Calculate StdDev across the columns of the new data frame
    toRetDF['Std Dev'] = toRetDF.std(axis=1)
    
    #Sort by deviation
    toRetDF.sort_values('Std Dev',inplace=True,ascending=False)
    toRetDF.to_csv(intermediateDir+"/stdDev_for_Filtering.csv")
        
    #Impose the top X% cutoff
    nRows=len(toRetDF.index)

    #Top x percent
    numToKeep=round(nRows*(percentToKeep/100.0))    
    print("Total number of rows: ",nRows)
    print("Rows kept: ",numToKeep)

    #Get the row ids of the rows to keep
    allRows=list(toRetDF.index)
    fRowIDs=[]
    for i in range(0,int(numToKeep)):
        fRowIDs.append(allRows[i])
    
    finalDF=pd.DataFrame()
    #Create the final data frame (recover the original rows that match the tags of the highest inter group varients)
    #For each row in the original
    for index, row in pdDF.iterrows():
        #Add the index if it is in the list of those to keep
        if index in fRowIDs:
            finalDF = finalDF.append(row)                
    return(finalDF)    

def moveFinalDFCol(pdDF):
    """
    Takes a pandas dataframe and moves the final column to the start.
    """
    cols = pdDF.columns.tolist()
    cols = cols[-1:] + cols[:-1]
    df = pdDF[cols]
    return(df)

def run(inpTSV,outDir,threshold,groups,intraFC,PTC):
    #Generate an output directory to dump the intermediate files into 
    intermediateDir=outDir+"/filteringFiles"
    os.system("mkdir "+intermediateDir)
    print(groups)
    #Convert groups from CL string to python list
    groups=stringTList2(groups)
    print("GROUPS: ",groups)
    #Load the data
    myDF = pd.read_csv(inpTSV, header=0,engine='python')

    #Filter 1: Expression threshold
    #Remove under threshold
    overThreshDF=removeUnderThreshold(myDF,float(threshold))
    
    #Save the newly filtered dataset
    overThreshDF.to_csv(intermediateDir+"/genes_Above_Threshold.csv",index=False)
    
    #Creat two boxplots of this distribution to be able to visualize gene expression distribution
    ax=overThreshDF.plot.box(showfliers=False)
    ax.set_xticklabels(overThreshDF.columns,rotation=90)
    fig = ax.get_figure()
    fig.tight_layout()
    fig.suptitle('Distribution of Gene Expression Above Threshold (outliers removed)')
    fig.savefig(intermediateDir+'/gene_expression_post_threshold_boxplot_noOutliers.pdf')
    ax2=overThreshDF.plot.box()
    ax2.set_xticklabels(overThreshDF.columns,rotation=90)
    fig = ax2.get_figure()
    fig.tight_layout()
    fig.suptitle('Distribution of Gene Expression Above Threshold')
    fig.savefig(intermediateDir+'/gene_expression_post_threshold_boxplot.pdf')
    
    #Filter 2: Intra-group variation
    withoutIntra = removeIntraGroupVariation(overThreshDF,groups,float(intraFC),outDir)
    print("Without intra: ",withoutIntra)
    if type(withoutIntra)!=bool:
        withoutIntra.to_csv(intermediateDir+"/after_rows_removed_from_intra_group_variation.csv",index=False)
        #Filter 3: Select the genes of highest variation between groups
        finalDF = selectHighestVariationGenes(withoutIntra,groups,float(PTC),outDir)
    else:
        finalDF = selectHighestVariationGenes(overThreshDF,groups,float(PTC),outDir)    
    
    finalDF=moveFinalDFCol(finalDF)
    finalDF.to_csv(outDir+"/filtered_data_forPCA.csv",index=False)
    
    #Finally, create a temporary file without gene ID to serve as a matrix entry for the PCA calculations
    forPCA=finalDF
    forPCA = forPCA.drop(['gene_id'], axis=1)
    forPCA.to_csv(outDir+"pre_PCA_Temp.csv",index=False)
    
    
#Run--------------------------------------------------------------------------------------
run(myInput,outDir,thresh,groups,intraFoldCeiling,percentToKeep)    
