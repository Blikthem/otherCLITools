#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 10:38:22 2020

@author: claypooldj
"""
#Load dependencies
import sys
import os


#INPUT VARIABLES (CL)------------------------------------------------------------------------------------------
#Argument 1 - Input directory
inpDir=sys.argv[1]
#Argument 2 - zScore tsv
zScoreTSV=sys.argv[2]
#Argument 3 - Cluster csv file
clustCSV=sys.argv[3]
#Argument 4 - Output directory
outDir=sys.argv[4]
#Argument 5 - Directory containing the csv file
csvDirectory=sys.argv[5]
#Argument 6 - The fasta used as reference
theInputFASTA=sys.argv[6]

#Run---------------------------------------------------------------------------------------------------------
#Make the subdirectory
stN = zScoreTSV[0:len(zScoreTSV)-4]
stN=stN.replace("_kMerZScores_","_")    
nSub=outDir+"/"+stN
if not os.path.exists(nSub):
    os.mkdir(nSub)
outDir=nSub
print("OutDir from the pipeline: ",outDir)
#Run intersection with cluster file
print("Generating the intersection file...")
from visualizeZScores_7 import run
run(inpDir,zScoreTSV,clustCSV,outDir,csvDirectory,theInputFASTA)

    #Establish the name of the comparison csv 
comparisonCSV=outDir+"/"+stN+"_kMers.csv"

#Generate weighted nucleotide distribution plots
print("Generated the weighted nucleotide distribution plots...")
from visualizeZScores_WeightedDistribution_v2 import run
run(comparisonCSV,outDir,1.96)

#Generate interactive scatter plot
print("Generating interactive scatter plot...")
from visualizeZScores_colorGraphs_Interactive import run
run(comparisonCSV,outDir)

#Generate the comparison with the fasta
print("Generating interactive scatter plot comparing clusters with reference...")
from visualizeZScores_compareWithFASTA import run
run(comparisonCSV,outDir)

print("...Finished.")
