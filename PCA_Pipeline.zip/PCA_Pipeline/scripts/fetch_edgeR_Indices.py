#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct  2 16:18:16 2019

@author: claypooldj
"""
import pandas as pd
import sys

#Inputs---------------------------------------------------------
#Name of the csv file which contains the gene expression data frame.
#dfString ="/Users/claypooldj/Desktop/geneExpressionMatrix_ExpectedCounts.tsv"
dfString=sys.argv[1]
#The inputed groups
inpGroups= sys.argv[2]
#inpGroups=[["sub1","sub2"],["sub3","sub4"],["T1","T2"]]
print(sys.argv[1])
print(sys.argv[2])
#----------------------------------------------------------------
def stringTList2(strGroup):
    toRet=[]
    if len(strGroup)<=2:
        return(toRet)
    if ',' not in strGroup:
        return(toRet)
    nGroup=[]
    toAdd=""
    for i in range(1,len(strGroup)-1):
        val=strGroup[i]
        if val not in ("[","]",","):
            toAdd=toAdd+val
        if val=="," and strGroup[i-1]!="]":
            nGroup.append(toAdd)
            toAdd=""
        if val=="]":
            nGroup.append(toAdd)
            toAdd=""
            toRet.append(nGroup)
            nGroup=[]
    return(toRet)
    
#Read in dataframe
df=pd.read_csv(dfString,sep='\t')


#Empty list which will contain the column indices of the groups
colIndList=[]

#Convert groups from CL string to python list
#groups=inpGroups
groups=stringTList2(inpGroups)

#If it is empty just return a count up vector
if ',' not in str(groups):
    print("No Groups inputed, assuming each column is its own group.")
    for val in range(1,len(df.columns)):
        colIndList.append(val)

#For each column in the data frame...
else:
    for indivCol in df.columns:
        #Find the associated group
        for i in range(0,len(groups)):
            for indivVal in groups[i]:
                if indivVal in indivCol:
                    colIndList.append(i+1)

toWrite=str(tuple(colIndList))
toWrite=toWrite.replace(" ","")
print(toWrite)
sys.stdout.write(toWrite)        
    
