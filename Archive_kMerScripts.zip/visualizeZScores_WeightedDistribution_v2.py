#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 12:03:24 2020

@author: claypooldj
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

#Inputs------------------------------------------------------------------------------------
"""
comparisonCSV="/Volumes/Untitled/Kazu/CLR_v_Exp/kMerAnalysis/FH_SBNO2_DEAD_A_2931_RPI9_S6_L005_R1_001.clusters_kMers.csv"
inputDirectory="/Volumes/Untitled/Output/kMerBackground/testDitto/withOldBackground/ToVisualize"
outputDirectory="/Volumes/Untitled/Output/kMerBackground/testDitto/withOldBackground"
"""
zScoreThresh=1.96
#------------------------------------------------------------------------------------

def getWNucleotideDistributionDict(compCSV,zScoreCutoff):
    """
    Get a dictionary representation of the weighted nucleotide distribution of clusters within kMers.
    Input:
        compCSV(Str) - Input cluster comparison file.
        zScoreCutoff(num) - The minimum magnitude of z score needed to use the row.
    Output:
        Dictionary:
            key - A, T, G, or C
            Value - [Distribton list]
    """
    df=pd.read_csv(compCSV)
    
    #Loop over the rows
    distributionDicts=[]
    for index, row in df.iterrows():
        if float(row["z-Score"])>=zScoreCutoff:
            roDist=getWRowNucleotideDistribution(row)
            distributionDicts.append(roDist)
    
    #Create a data frame for each nucleotide
    ALL=[]
    ULL=[]
    GLL=[]
    CLL=[]
    for indDict in distributionDicts:
        ALL.append(indDict["A"])
        ULL.append(indDict["U"])
        GLL.append(indDict["G"])
        CLL.append(indDict["C"])
    
    ADF=pd.DataFrame(ALL)
    UDF=pd.DataFrame(ULL)
    GDF=pd.DataFrame(GLL)
    CDF=pd.DataFrame(CLL)
    
    toRet={}
    toRet["A"]=list(ADF.mean())
    toRet["U"]=list(UDF.mean())
    toRet["G"]=list(GDF.mean())
    toRet["C"]=list(CDF.mean())

    return(toRet)
    
def getWRowNucleotideDistribution(row):
    """
    Takes a row dictionary and returns the weighted distribution lists for each nucleotide.
    """
    AList=[]
    UList=[]
    GList=[]
    CList=[]
    for indCh in row["kMer"]:
        if indCh=="A":
            AList.append(row["% cluster read space"])
            UList.append(0)
            GList.append(0)
            CList.append(0)
        if indCh=="U":
            AList.append(0)
            UList.append(row["% cluster read space"])
            GList.append(0)
            CList.append(0)
        if indCh=="G":
            AList.append(0)
            UList.append(0)
            GList.append(row["% cluster read space"])
            CList.append(0)
        if indCh=="C":
            AList.append(0)
            UList.append(0)
            GList.append(0)
            CList.append(row["% cluster read space"])
    toRet={}
    toRet["A"]=AList
    toRet["U"]=UList
    toRet["G"]=GList
    toRet["C"]=CList
    return(toRet)

def createNucleotideDistGraph(outDir,distributionDict,fName,zScore):
    """
    Represents a dictionary of nucleotide distributions on a graph.
    Input:
        distributionDict - Dict[A -> List[num]]
        outDir(str) - Where to save the graph.
    Saves:
        Distribution graph in output directory.
    """
    ind=[]
    width = 0.35
    for i in range(0,len(distributionDict["A"])):
        ind.append(i)
        
    p1 = plt.bar(ind, distributionDict["A"], width,bottom=0,color='green')
    p2 = plt.bar(ind, distributionDict["U"], width,bottom=np.array(distributionDict["A"]),color='firebrick')
    p3 = plt.bar(ind, distributionDict["G"], width,bottom=np.array(distributionDict["A"])+np.array(distributionDict["U"]),color='gold')
    p4 = plt.bar(ind, distributionDict["C"], width,bottom=np.array(distributionDict["A"])+np.array(distributionDict["U"])+np.array(distributionDict["G"]),color='mediumblue')
    plt.title(" ZScore Threshold: "+str(zScore),fontsize=12)
    plt.suptitle("Nucleotide Distribution: "+fName,fontsize=13)
    plt.ylabel("Weighted (to cluster %) Abundance")
    plt.xlabel("Nucleotide Index")
    plt.legend((p1[0], p2[0],p3[0],p4[0]), ('A', 'U','G','C'))
    toSave=outDir+"/"+fName+"_NucDistribution_Z"+str(zScore)+".pdf"
    plt.savefig(toSave)
    plt.show()    
    
#Run------------------------------------------------------------------------------------
def run(compCSV,outDir,zScoreThresh):
    fName= os.path.basename(compCSV)
    fName2=os.path.splitext(fName)[0]
    
    WNDistDict=getWNucleotideDistributionDict(compCSV,0)
    print("Weighted distribution - All Rows")
    print(WNDistDict)
    
    WNDistDict_Sig=getWNucleotideDistributionDict(compCSV,zScoreThresh)
    print("Weighted distribution - Abs(z score)>=zScore: "+str(zScoreThresh))
    print(WNDistDict_Sig)
    
    createNucleotideDistGraph(outDir,WNDistDict,fName2,0)
    if len(WNDistDict_Sig['A'])==0 or len(WNDistDict_Sig['U'])==0 or len(WNDistDict_Sig['G'])==0 or len(WNDistDict_Sig['C'])==0:
        return()
    createNucleotideDistGraph(outDir,WNDistDict_Sig,fName2,zScoreThresh)
    
def runOnALlInDirectory(inpDir,outDir,zScoreThresh):
    filesToAnalyze=os.listdir(inpDir)
    for indF in filesToAnalyze:
        if ".csv" in indF:
            print(indF)
            run(inpDir+"/"+indF,outDir,zScoreThresh)

#runOnALlInDirectory(inputDirectory,outputDirectory,zScoreThresh)