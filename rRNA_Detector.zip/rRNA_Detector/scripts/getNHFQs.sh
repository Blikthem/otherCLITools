inpDir="/home/claypooldj/rRNADepletion/blat/engine_output"

toParse=$inpDir
toParse+="/*_rRNA_Mapped"

cd $inpDir
mkdir noHitFastqs
toOut=$inpDir
toOut+="/noHitFastqs/"

for dir in $toParse
do
 #Get the name of the final directory to use in naming the fastq file
 SRC="$(basename $dir)"
 fqName=$(printf '%s\n' "${SRC//_rRNA_Mapped/}")
 fqName+="_noHits.fastq"
 echo $fqName

 finalOut=$toOut
 finalOut+=$fqName
 echo $finalOut

 #To copy
 toCopy=$dir
 toCopy+="/unmapped.fastq"
 
 echo $toCopy

 cp $toCopy $finalOut
 
done

