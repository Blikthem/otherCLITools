#!/bin/bash
module load star/2.5.2b
module load rsem/1.1.21
module load python/2.7.16
module load python/3.7.2
module load R/3.5.3
module load samtools/1.9

echo "Pipeline for aligning, quantifying, and comparing RNA-Seq results (DJC)"
echo "--------------------------------------------------------------------------"

#INPUT VARIABLES AND DESCRIPTIONS------------------------------------------
#Input 1 -> The directory which contains the mapped sam files to quanitfy and work with.
#Input 2 -> The STAR index directory  to use for annotation.
#Input 3 -> Output directory
#Input 4 -> The RSEM reference to use for expression quantification, in path/prefix form (ex /home/claypooldj/genomes/RSEM/rsem_hg38)
	#OPTIONAL INPUT
#Input 5 -> Groups. Here is where you say which fastq files are replicates of a biological condition. This is used to remove genes that show high variation within a group. Format as follows:
#	Input 5 format: Each group should be written in [] which contain string of each input file. DO NOT INCLUDE THE FILE EXTENSION (.fastq, .fastq.gz etc) Place each of these group in an outer [] seperated by commas. Ommited input files are assumed to be part of no group.
#	Input 5 example: [["sample_A1","sample_A2"],["sample_B1","sample_B2"]] 
echo "--------------------------------------------------------------------------"

check=$5
#Required Inputs
INPUTDIR=${1?Error: no input directory (the directory with fastqs) specified. Variable 1.}
ANOT=${2?Error: no STAR annotation directory specified. Variable 2.}
OUTDIR=${3?Error: no output directory specified. Variable 3.}
RSEMREF=${4?Error: no RSEM reference path specified. Variable 4.}
GROUPS=${5?Error: no groups included. Variable 5. If there are no replicates, simply enter []}

echo "Quantifying expression levels for, and performing PCA upon all sam files in this directory: $INPUTDIR"
echo "and this RSEM reference: $RSEMREF"
echo "and outputing all results into: $OUTDIR"
echo "using these groups: $check"

#Detect	the script directory from the location of the pipeline executable
toS=$(pwd)
mine=$(find $toS -name "PCA_Pipe.sh" -print)
scriptDir=`dirname $mine`
echo $scriptDir
echo "Script dir $scriptDir"
cd $INPUTDIR

#Loop over all fastq'ss and fastq.gz's
for ext in ".bam"
do
 echo "Currently checking for: $ext"
 for f in *$ext
 do
  if [[ $f != *"*$ext"* ]]; then
   echo $f
   fName=$(echo "$f" | cut -f 1 -d '.')

   #Step 2: RSEM transcript quantification
    #Transcriptom bam file name
   rsemOut=$OUTDIR
   rsemOut+="/RSEM_"
   rsemOut+=$fName
   #mkdir $rsemOut
   rsemOut+="/rsem_"   
   echo "Running RSEM quantification..."
#   rsem-calculate-expression --paired-end --bam $f $RSEMREF $rsemOut 
   
   #Copy the gene output file into a new directory to act upon later (to combine)
   collectedDir=$OUTDIR
   collectedDir+="/allGeneResults"
  # mkdir $collectedDir
   copyInto=$collectedDir
   copyInto+="/"
   copyInto+=$fName
   toCopy=$rsemOut
   toCopy+=".genes.results"
 #  cp $toCopy $copyInto

  fi
 done
done

#Combine the gene quantification spreadsheets into a master sheet

#Create a string to populate as the left parameter of the rsem-generate-data-matrix function
toJoin=""

#Populate a combine variable for all of the files in this other data base
for f in $collectedDir/*
do
 toJoin+=$f
 toJoin+=" "
done

echo "Combining" $toJoin

#Run the rsem combination and output the results to the output directory
outPut=$3
outPut+="/geneExpressionMatrix_ExpectedCounts.tsv"
#rsem-generate-data-matrix $toJoin >$outPut

#Generate TPM and FPKM values
echo "Generating TPM adn FPKM values..."
#python /home/claypooldj/PCA_Pipeline/scripts/create_TPM_FPKM_Out.py $3

outPut=$3
outPut+="geneExpressionMatrix_TPM.csv"

#Run the differential expression analysis (both with and without trimmed mean values)

#First, fetch the indices of the columns of interest
#Establish fetch indices command
fetIndicesCom=$scriptDir
echo "Script dir: $fetIndicesCom"
fetIndicesCom+="/fetch_edgeR_Indices.py"
echo "Fet Indices Command: $fetIndicesCom"
#Establish input1 (the counts matrix)
ficInp1=$OUTDIR
ficInp1+="/geneExpressionMatrix_ExpectedCounts.tsv"
echo "ficInp1 $ficInp1"
theGroups=$check
echo "Groups: $theGroups"
echo "python $fetIndicesCom $check"

#Fetch the indices for R input
commandOutput=$(python $fetIndicesCom $ficInp1 $check)
pyIntermediate=$OUTDIR
pyIntermediate+="/pyIntermediate.txt"
echo "$commandOutput" > $pyIntermediate
myGIndices=$(tail -1 $pyIntermediate)
rm $pyIntermediate
echo "My Indices: $myGIndices"

#Now perform the differential expression analysis using these groups
#Establish the command
edgCom=$scriptDir
edgCom+="/edgeR_DE_CLI.R"
echo $edgCom
Rscript $edgCom $ficInp1 $myGIndices $OUTDIR
